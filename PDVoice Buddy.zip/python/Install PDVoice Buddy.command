#!/bin/bash
# PDVoice Buddy — double-click installer for macOS and Linux.
# Sets up everything, makes a one-click launcher, and starts the app.

set -e
cd "$(dirname "$0")"

echo ""
echo "  PDVoice Buddy — installing"
echo "  ─────────────────────────────────────────"
echo ""

# --- 1. Python -------------------------------------------------------------

if ! command -v python3 >/dev/null 2>&1; then
  echo "  Python 3 isn't installed yet."
  echo ""
  if [ "$(uname)" = "Darwin" ]; then
    echo "  A window will open asking to install developer tools."
    echo "  Click Install, wait for it to finish, then double-click"
    echo "  this installer again."
    echo ""
    xcode-select --install 2>/dev/null || true
  else
    echo "  Install it with:  sudo apt install python3 python3-venv"
    echo ""
  fi
  read -n 1 -s -r -p "  Press any key to close."
  exit 1
fi

echo "  ✓ Found $(python3 --version)"

# --- 2. Dependencies -------------------------------------------------------

if [ ! -d ".venv" ]; then
  echo "  · Creating a private environment for the app…"
  python3 -m venv .venv
fi

echo "  · Downloading what it needs (this takes a minute the first time)…"
./.venv/bin/python -m pip install --quiet --upgrade pip
./.venv/bin/python -m pip install --quiet -r requirements.txt

echo "  ✓ Ready"

# --- 3. One-click launcher -------------------------------------------------

APP_DIR="$(pwd)"

cat > "PDVoice Buddy.command" <<LAUNCHER
#!/bin/bash
cd "$APP_DIR"
exec ./.venv/bin/python pdvoice_buddy.py
LAUNCHER
chmod +x "PDVoice Buddy.command"

# Put a copy on the Desktop so it looks and behaves like an installed app.
if [ -d "$HOME/Desktop" ]; then
  cp "PDVoice Buddy.command" "$HOME/Desktop/PDVoice Buddy.command" 2>/dev/null || true
  chmod +x "$HOME/Desktop/PDVoice Buddy.command" 2>/dev/null || true
  echo "  ✓ Put 'PDVoice Buddy' on your Desktop"
fi

echo ""
echo "  ─────────────────────────────────────────"
echo "  Done. Starting it now."
echo ""
echo "  Your Mac will ask for microphone access."
echo "  Click OK — nothing is ever recorded."
echo ""
echo "  From now on, just double-click PDVoice Buddy"
echo "  on your Desktop."
echo ""

# --- 4. Go -----------------------------------------------------------------

./.venv/bin/python pdvoice_buddy.py
