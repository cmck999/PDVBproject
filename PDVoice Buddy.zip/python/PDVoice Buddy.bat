@echo off
cd /d "%~dp0"
set "PY="
if exist ".venv\Scripts\pythonw.exe" set "PY=.venv\Scripts\pythonw.exe"
if not defined PY if exist "..\.venv\Scripts\pythonw.exe" set "PY=..\.venv\Scripts\pythonw.exe"
if not defined PY if exist "..\..\.venv\Scripts\pythonw.exe" set "PY=..\..\.venv\Scripts\pythonw.exe"
if not defined PY if exist "..\..\..\.venv\Scripts\pythonw.exe" set "PY=..\..\..\.venv\Scripts\pythonw.exe"
if not defined PY (
  where pythonw >nul 2>nul && set "PY=pythonw"
)
if not defined PY (
  echo Could not find Python. Run "Show errors.bat" for details.
  pause
  exit /b
)
start "" %PY% "pdvoice_buddy.py"
