"""
PDVoice Buddy — desktop
A glowing dot that stays bright while your voice is carrying.
For hypophonia in Parkinson's disease.

This mirrors the Android version: same measurement model, same five
sensitivity steps, same four colours, same two shapes, same controls.

Nothing is recorded. Each block of audio produces one loudness number and is
immediately discarded.

    pip install -r requirements.txt
    python pdvoice_buddy.py

Not a medical device.
"""

import math
import platform
import threading
import sys
from pathlib import Path

import numpy as np
import updates
import sounddevice as sd
from PySide6.QtCore import QPointF, QRectF, QSettings, QSize, Qt, QTimer
from PySide6.QtGui import (
    QBrush, QColor, QIcon, QPainter, QPainterPath, QPixmap, QPolygonF,
    QRadialGradient,
)
from PySide6.QtWidgets import (
    QApplication, QFrame, QHBoxLayout, QLabel, QMenu, QPushButton,
    QSystemTrayIcon, QVBoxLayout, QWidget,
)

# ---------------------------------------------------------------- tuning ----

SAMPLE_RATE = 44100
BLOCK = 2048           # ~46 ms — one VoiceCue frame, as on Android
RENDER_MS = 40         # how often the screen is repainted

PILL_WIDTH = 336
PILL_DOT = 30
FULL_DOT = 260

BG = "#0f1218"
EDGE = "#2b313c"
DIM = "#8c8f96"
DIM_PAUSED = "#5b6068"
INK = "#e6e8ec"
MUTED_INK = "#8d929a"

# ---------------------------------------------------------------- language --
# Android switches language by itself; on the desktop it has to be done by
# hand. English strings ARE the keys, so anything missing from the table falls
# through untranslated rather than showing a blank or a raw identifier.
#
# Spanish is Latin American and uses "usted" throughout: these are mostly older
# adults being addressed by a health tool, where "tú" would read as familiar.

SPANISH = {
    # the words under the dot
    "Paused": "En pausa",
    "Starting up": "Iniciando",
    "Listening to the room": "Escuchando la sala",
    "Heard": "Se oye",
    "Louder": "M\u00e1s fuerte",
    "No microphone": "Sin micr\u00f3fono",

    # sensitivity
    "Gentle": "Suave",
    "Easy": "F\u00e1cil",
    "Normal": "Normal",
    "Firm": "Firme",
    "Strong": "Fuerte",

    # colours
    "Mint": "Menta",
    "Amber": "\u00c1mbar",
    "Sky": "Cielo",
    "White": "Blanco",

    # settings
    "HOW LOUD YOU NEED TO BE": "QU\u00c9 TAN FUERTE HABLAR",
    "COLOUR": "COLOR",
    "SIZE": "TAMA\u00d1O",
    "LANGUAGE": "IDIOMA",
    "MICROPHONE CALIBRATION": "CALIBRACI\u00d3N DEL MICR\u00d3FONO",
    "UPDATES": "ACTUALIZACIONES",
    "You have version {}": "Usted tiene la versi\u00f3n {}",
    "You have version {} \u2014 this is the newest":
        "Usted tiene la versi\u00f3n {} \u2014 es la m\u00e1s reciente",
    "Version {} is ready": "La versi\u00f3n {} est\u00e1 lista",
    "Please update \u2014 version {}": "Por favor actualice \u2014 versi\u00f3n {}",
    "Check now": "Buscar ahora",
    "Checking\u2026": "Buscando\u2026",
    "Update now": "Actualizar ahora",
    "Later": "M\u00e1s tarde",
    "Downloading\u2026": "Descargando\u2026",
    "Downloading\u2026 {}%": "Descargando\u2026 {}%",
    "The download failed. Try again later.":
        "La descarga fall\u00f3. Int\u00e9ntelo m\u00e1s tarde.",
    "Could not install it. Try again later.":
        "No se pudo instalar. Int\u00e9ntelo m\u00e1s tarde.",
    "It will download, replace itself and restart. Your settings are kept.":
        "Se descargar\u00e1, se reemplazar\u00e1 y se reiniciar\u00e1. Sus ajustes se conservan.",
    "Open PDVoice Buddy settings to install it.":
        "Abra los ajustes de PDVoice Buddy para instalarla.",
    "Only worth touching if the dot seems far too easy or far too hard everywhere. Speak normally at arm's length and compare with a sound level meter app.":
        "Solo vale la pena cambiarla si el punto parece demasiado f\u00e1cil o demasiado dif\u00edcil en todas partes. Hable normalmente a un brazo de distancia y compare con una aplicaci\u00f3n de son\u00f3metro.",
    "Now: quiet": "Ahora: silencio",
    "Now: about {} dB": "Ahora: unos {} dB",
    "bar {} dB": "nivel {} dB",
    "Reset": "Restablecer",
    "Normal conversation is 60\u201370 dB. The dot needs your voice above the room AND above this level, so a quiet room no longer lets a whisper through.":
        "Una conversaci\u00f3n normal est\u00e1 entre 60 y 70 dB. El punto necesita que su voz est\u00e9 por encima de la sala Y por encima de este nivel, para que una sala silenciosa ya no permita un susurro.",
    "below conversational \u2014 a starting point": "por debajo de lo conversacional \u2014 para empezar",
    "a relaxed voice, about 60 dB": "una voz relajada, unos 60 dB",
    "conversational, about 63 dB": "conversacional, unos 63 dB",
    "projecting, about 66 dB": "proyectando, unos 66 dB",
    "strong projection, about 69 dB": "proyecci\u00f3n fuerte, unos 69 dB",
    "Automatic": "Autom\u00e1tico",
    "Full screen": "Pantalla completa",
    "Small pill": "Barra peque\u00f1a",
    "Open at login": "Abrir al iniciar sesi\u00f3n",
    "Quit": "Salir",
    "PDVoice Buddy \u2014 Settings": "PDVoice Buddy \u2014 Ajustes",
    ". If the dot is dark most of the time, go down a step.":
        ". Si el punto est\u00e1 apagado la mayor parte del tiempo, baje un paso.",

    # buttons and menus
    "Settings": "Ajustes",
    "Settings\u2026": "Ajustes\u2026",
    "Start listening": "Empezar a escuchar",
    "Pause listening": "Pausar la escucha",
    "Show": "Mostrar",
    "Hide": "Ocultar",
    "Quit PDVoice Buddy": "Salir de PDVoice Buddy",
    "Hide \u2014 click the tray icon to bring it back":
        "Ocultar \u2014 haga clic en el icono junto al reloj para volver",
    "Click anywhere for settings   \u00b7   Esc to hide":
        "Haga clic en cualquier lugar para los ajustes   \u00b7   Esc para ocultar",
    "PDVoice Buddy \u2014 click to show or hide":
        "PDVoice Buddy \u2014 haga clic para mostrar u ocultar",
    "PDVoice Buddy is still listening": "PDVoice Buddy sigue escuchando",
    "Click this icon to bring it back. Right-click it for Quit.":
        "Haga clic en este icono para volver. Clic derecho para salir.",
}


def _system_language():
    """The device language, or --lang=es to force it for testing."""
    for arg in sys.argv[1:]:
        if arg.startswith("--lang="):
            return arg.split("=", 1)[1].lower()
    name = ""
    if sys.platform == "win32":
        # Windows reports locale names like "Spanish_Spain" through the stdlib,
        # which is useless for matching; ask the OS for the real tag.
        try:
            import ctypes
            buf = ctypes.create_unicode_buffer(85)
            ctypes.windll.kernel32.GetUserDefaultLocaleName(buf, 85)
            name = buf.value or ""
        except Exception:
            pass
    if not name:
        try:
            import locale
            name = (locale.getlocale()[0] or "")
        except Exception:
            pass
    if not name:
        import os
        name = os.environ.get("LANG") or os.environ.get("LC_ALL") or ""
    return name.lower().replace("_", "-")


LANG_AUTO = "auto"
LANG_EN = "en"
LANG_ES = "es"

# Named in their own language, never translated: someone hunting for Spanish
# on an English computer has to recognise "Español" on sight.
LANGUAGES = [(LANG_AUTO, None), (LANG_EN, "English"), (LANG_ES, "Espa\u00f1ol")]

TABLES = {LANG_ES: SPANISH}

# Set once at startup and whenever the setting changes. Module-level because
# _() is called from everywhere, including inside widget constructors.
_WORDS = {}


def set_language(choice):
    """choice is LANG_AUTO / LANG_EN / LANG_ES."""
    global _WORDS
    code = _system_language() if choice == LANG_AUTO else choice
    key = LANG_ES if (code.startswith("es") or code.startswith("spanish")) else LANG_EN
    _WORDS = TABLES.get(key, {})


set_language(LANG_AUTO)


def _(text):
    return _WORDS.get(text, text)


# The five steps. Same five as Android, and each carries TWO numbers, because
# the dot needs the voice to clear both:
#
#   margin_db  — how far above the room. Handles noisy places.
#   target_spl — an absolute level in dB SPL. Handles quiet places, where
#                clearing the room proves nothing.
#
# The targets run across the normal conversational band, 60-70 dB, which is the
# level the app exists to encourage. Gentle sits just below it as a starting
# point for someone who cannot reach 60 yet.
EFFORTS = [
    ("Gentle", "below conversational — a starting point", 7.0, 57.0),
    ("Easy", "a relaxed voice, about 60 dB", 10.0, 60.0),
    ("Normal", "conversational, about 63 dB", 13.0, 63.0),
    ("Firm", "projecting, about 66 dB", 16.0, 66.0),
    ("Strong", "strong projection, about 69 dB", 19.0, 69.0),
]

# dB SPL = dBFS + this.
#
# A computer microphone is not a sound level meter: no absolute reference, gain
# varies by machine, and the reading falls off with distance. So this is an
# approximation, adjustable against a real meter, defaulting to a
# middle-of-the-road guess at roughly an arm's length.
#
# Being wrong by a few dB does not break anything — the relative half is
# unaffected and the absolute half only shifts slightly. It is not, and must
# never be presented as, a measurement.
DEFAULT_MIC_OFFSET = 95.0

COLOURS = [
    ("Mint", "#2BFFA3"),
    ("Amber", "#FFC53D"),
    ("Sky", "#57C7FF"),
    ("White", "#F2F5F7"),
]

SHAPE_FULL = 0
SHAPE_PILL = 1

# ------------------------------------------------------------- the model ----


class VoiceCue:
    """
    The whole measurement — a direct port of the Android VoiceCue, kept
    line-for-line comparable on purpose so the two platforms can never drift
    apart in behaviour.

    TWO thresholds, and the dot lights only when the voice clears BOTH:

      1. Above the room, by margin_db. Being audible is relative — the same
         voice that carries in a kitchen is lost in a restaurant, and no fixed
         number can express that.

      2. Above an absolute level, target_dbfs. Because the point is not merely
         to be audible: it is to practise projecting at a normal conversational
         volume, roughly 60-70 dB. In a silent room the relative test alone
         would light up for a whisper, which teaches exactly the wrong habit.

    Equivalently: the bar is whichever of the two is higher. The room decides
    in a restaurant; the absolute target decides in a quiet living room.

    target_dbfs=None disables the absolute half entirely. That is the honest
    way to exercise the relative half on its own, not a real configuration.
    """

    def __init__(self, margin_db=13.0, target_dbfs=None, hold_ms=700.0,
                 fall_rate=0.05, rise_rate=0.006, speech_margin_db=6.0,
                 warm_up_ms=1500.0):
        self.margin_db = margin_db
        self.target_dbfs = target_dbfs
        self.hold_ms = hold_ms
        self.fall_rate = fall_rate
        self.rise_rate = rise_rate
        self.speech_margin_db = speech_margin_db
        self.warm_up_ms = warm_up_ms
        self.reset()

    def reset(self):
        self.floor_db = 0.0
        self.started_at = None
        self.last_above = -1e9
        self.lit = False
        self.level = 0.0
        self.above_db = 0.0
        self.db = -120.0
        self.threshold_db = 0.0
        self.absolute_binding = False
        self.ready = False
        self.warming_left_ms = self.warm_up_ms

    def push_db(self, db, now_ms):
        if self.started_at is None:
            self.started_at = now_ms
            self.floor_db = db

        warming = (now_ms - self.started_at) < self.warm_up_ms
        self.warming_left_ms = max(0.0, self.warm_up_ms - (now_ms - self.started_at))

        if warming:
            # Learning the room: follow it quickly, up or down.
            self.floor_db += (db - self.floor_db) * 0.25
        elif db < self.floor_db:
            # Settled: drops fast, rises slowly, so a sentence cannot drag the
            # floor up behind itself, but a passing lorry still raises the bar.
            self.floor_db += (db - self.floor_db) * self.fall_rate
        else:
            self.floor_db += (db - self.floor_db) * self.rise_rate

        relative = self.floor_db + self.margin_db
        absolute = -1e9 if self.target_dbfs is None else self.target_dbfs
        threshold = max(relative, absolute)

        if not warming and db >= threshold:
            self.last_above = now_ms

        # The dot grows as she approaches the bar, so effort is visible before
        # it is rewarded. Span scales with the margin to keep the old feel.
        span = self.margin_db + 8.0

        self.db = db
        self.threshold_db = threshold
        self.absolute_binding = absolute > relative
        self.above_db = db - self.floor_db
        self.lit = (not warming) and (now_ms - self.last_above) < self.hold_ms
        self.level = max(0.0, min(1.0, (db - threshold + span) / (span + 6.0)))
        self.ready = not warming
        return self

    @staticmethod
    def db_of(samples):
        """dBFS. Negative. Meaningless alone without a calibration offset."""
        if samples.size == 0:
            return -120.0
        rms = float(np.sqrt(np.mean(np.square(samples))))
        return 20.0 * math.log10(max(rms, 1e-7))


# ------------------------------------------------------------ audio input ---


class Meter:
    """Owns the input stream and feeds the model. Keeps no audio."""

    def __init__(self, cue):
        self.cue = cue
        self.stream = None
        self.error = None
        self.frames = 0

    def start(self):
        if self.stream is not None:
            return
        self.cue.reset()
        self.frames = 0
        try:
            self.stream = sd.InputStream(
                channels=1, samplerate=SAMPLE_RATE, blocksize=BLOCK,
                callback=self._on_audio,
            )
            self.stream.start()
            self.error = None
        except Exception as exc:                      # no device, no permission
            self.stream = None
            self.error = str(exc)

    def stop(self):
        if self.stream is not None:
            self.stream.stop()
            self.stream.close()
            self.stream = None
        self.cue.reset()

    @property
    def running(self):
        return self.stream is not None

    def _on_audio(self, indata, frames, time_info, status):
        # Pushed from the audio thread, one frame at a time, exactly as on
        # Android. The maths is a handful of floats; the sound is discarded
        # the moment this returns.
        db = VoiceCue.db_of(indata[:, 0])
        self.frames += 1
        self.cue.push_db(db, self.frames * (BLOCK / SAMPLE_RATE) * 1000.0)


# ------------------------------------------------------------ the drawing ---


class Dot(QWidget):
    """The glowing dot. One painter, used at both sizes."""

    def __init__(self, diameter, parent=None):
        super().__init__(parent)
        self.diameter = diameter
        self.level = 0.0
        self.lit = False
        self.paused = False
        self.colour = QColor(COLOURS[0][1])
        span = int(diameter * 2.4)
        self.setFixedSize(span, span)
        self.setAttribute(Qt.WA_TransparentForMouseEvents)

    def sizeHint(self):
        return QSize(self.width(), self.height())

    def apply(self, lit, level, paused, colour):
        self.lit, self.level, self.paused = lit, level, paused
        self.colour = QColor(colour)
        self.update()

    def paintEvent(self, _event):
        p = QPainter(self)
        p.setRenderHint(QPainter.Antialiasing)
        c = self.rect().center()
        cx, cy = c.x() + 0.5, c.y() + 0.5
        centre = QPointF(cx, cy)

        base = self.diameter / 2.0
        level = 0.0 if self.paused else self.level
        core = base * (0.34 + 0.66 * level)
        col = QColor(self.colour) if self.lit else QColor(
            DIM_PAUSED if self.paused else DIM)

        if level > 0.01:
            halo = core * (2.1 + 1.5 * level)
            grad = QRadialGradient(centre, halo)
            inner = QColor(col)
            inner.setAlpha(int((155 if self.lit else 42) * min(1.0, level * 1.25)))
            mid = QColor(col)
            mid.setAlpha(int((62 if self.lit else 15) * level))
            outer = QColor(col)
            outer.setAlpha(0)
            grad.setColorAt(0.0, inner)
            grad.setColorAt(0.42, mid)
            grad.setColorAt(1.0, outer)
            p.setPen(Qt.NoPen)
            p.setBrush(QBrush(grad))
            p.drawEllipse(centre, halo, halo)

        p.setPen(Qt.NoPen)
        p.setBrush(col)
        p.drawEllipse(centre, core, core)
        p.end()


def _pix(size):
    pix = QPixmap(size, size)
    pix.fill(Qt.transparent)
    return pix


def icon_pause(colour, size=48):
    pix = _pix(size)
    p = QPainter(pix)
    p.setRenderHint(QPainter.Antialiasing)
    p.setPen(Qt.NoPen)
    p.setBrush(QColor(colour))
    w, h, gap = size * 0.13, size * 0.40, size * 0.11
    p.drawRoundedRect(QRectF(size / 2 - gap / 2 - w, (size - h) / 2, w, h),
                      w * 0.4, w * 0.4)
    p.drawRoundedRect(QRectF(size / 2 + gap / 2, (size - h) / 2, w, h),
                      w * 0.4, w * 0.4)
    p.end()
    return QIcon(pix)


def icon_play(colour, size=48):
    pix = _pix(size)
    p = QPainter(pix)
    p.setRenderHint(QPainter.Antialiasing)
    p.setPen(Qt.NoPen)
    p.setBrush(QColor(colour))
    r = size * 0.22
    cx, cy = size / 2 + size * 0.03, size / 2
    tri = QPolygonF([
        QPointF(cx - r * 0.85, cy - r),
        QPointF(cx - r * 0.85, cy + r),
        QPointF(cx + r, cy),
    ])
    path = QPainterPath()
    path.addPolygon(tri)
    path.closeSubpath()
    p.drawPath(path)
    p.end()
    return QIcon(pix)


def icon_gear(colour, size=48):
    pix = _pix(size)
    p = QPainter(pix)
    p.setRenderHint(QPainter.Antialiasing)
    p.setPen(Qt.NoPen)
    p.setBrush(QColor(colour))
    cx = cy = size / 2.0
    ring = size * 0.20
    tooth_w, tooth_h = size * 0.085, size * 0.115
    for i in range(8):
        p.save()
        p.translate(cx, cy)
        p.rotate(i * 45.0)
        p.drawRoundedRect(
            QRectF(-tooth_w / 2, -(ring + tooth_h * 0.85), tooth_w, tooth_h),
            tooth_w * 0.35, tooth_w * 0.35)
        p.restore()
    p.drawEllipse(QPointF(cx, cy), ring, ring)
    # punch the middle out, so it reads as a gear rather than a cog-shaped blob
    p.setCompositionMode(QPainter.CompositionMode_Clear)
    p.drawEllipse(QPointF(cx, cy), ring * 0.44, ring * 0.44)
    p.end()
    return QIcon(pix)


def icon_close(colour, size=48):
    pix = _pix(size)
    p = QPainter(pix)
    p.setRenderHint(QPainter.Antialiasing)
    pen = p.pen()
    pen.setColor(QColor(colour))
    pen.setWidthF(size * 0.085)
    pen.setCapStyle(Qt.RoundCap)
    p.setPen(pen)
    r = size * 0.17
    cx = cy = size / 2.0
    p.drawLine(QPointF(cx - r, cy - r), QPointF(cx + r, cy + r))
    p.drawLine(QPointF(cx + r, cy - r), QPointF(cx - r, cy + r))
    p.end()
    return QIcon(pix)


def flat_button(size=30, hover="#1b2028"):
    b = QPushButton()
    b.setFixedSize(size, size)
    b.setCursor(Qt.PointingHandCursor)
    b.setIconSize(QSize(int(size * 0.72), int(size * 0.72)))
    b.setStyleSheet(
        "QPushButton { border: none; background: transparent; border-radius: "
        + str(size // 2) + "px; }"
        "QPushButton:hover { background: " + hover + "; }"
    )
    return b


# ------------------------------------------------------------- the windows ---


class Pill(QWidget):
    """The small floating bar. Always on top, draggable, remembers where."""

    def __init__(self, app):
        super().__init__()
        self.app = app
        self.drag_origin = None

        self.setWindowFlags(Qt.FramelessWindowHint | Qt.WindowStaysOnTopHint | Qt.Tool)
        self.setAttribute(Qt.WA_TranslucentBackground)
        self.setWindowOpacity(0.97)
        self.setFixedWidth(PILL_WIDTH)

        outer = QVBoxLayout(self)
        outer.setContentsMargins(0, 0, 0, 0)
        self.card = QFrame(self)
        self.card.setObjectName("card")
        self.card.setStyleSheet(
            "QFrame#card { background-color: " + BG + "; border-radius: 30px;"
            " border: 1px solid " + EDGE + "; }"
        )
        outer.addWidget(self.card)

        row = QHBoxLayout(self.card)
        row.setContentsMargins(11, 9, 13, 9)
        row.setSpacing(9)

        self.dot = Dot(PILL_DOT)
        row.addWidget(self.dot)

        self.status = QLabel(_("Listening to the room"))
        self.status.setStyleSheet(
            "font-size: 14px; font-weight: 600; color: " + INK + ";")
        row.addWidget(self.status, 1)

        self.transport = flat_button()
        self.transport.clicked.connect(app.toggle_paused)
        row.addWidget(self.transport)

        self.gear = flat_button()
        self.gear.setIcon(icon_gear("#9aa0a8"))
        self.gear.setToolTip(_("Settings"))
        self.gear.clicked.connect(app.open_settings)
        row.addWidget(self.gear)

        self.close_btn = flat_button(26, hover="#2a1f1d")
        self.close_btn.setIcon(icon_close("#7f858d"))
        self.close_btn.setToolTip(_("Hide — click the tray icon to bring it back"))
        self.close_btn.clicked.connect(app.hide_to_tray)
        row.addWidget(self.close_btn)

    def place_default(self):
        screen = QApplication.primaryScreen().availableGeometry()
        self.adjustSize()
        x = self.app.settings.value("pillX", None)
        y = self.app.settings.value("pillY", None)
        if x is not None and y is not None:
            self.move(int(x), int(y))
        else:
            self.move(screen.right() - self.width() - 24,
                      screen.bottom() - self.height() - 24)

    def mousePressEvent(self, event):
        if event.button() == Qt.LeftButton:
            self.drag_origin = event.globalPosition().toPoint() - self.pos()

    def mouseMoveEvent(self, event):
        if self.drag_origin is not None and event.buttons() & Qt.LeftButton:
            self.move(event.globalPosition().toPoint() - self.drag_origin)

    def mouseReleaseEvent(self, _event):
        self.drag_origin = None
        self.app.settings.setValue("pillX", self.x())
        self.app.settings.setValue("pillY", self.y())

    def retranslate(self):
        self.gear.setToolTip(_("Settings"))
        self.close_btn.setToolTip(
            _("Hide — click the tray icon to bring it back"))

    def apply(self, lit, level, paused, colour, status):
        self.dot.apply(lit, level, paused, colour)
        self.status.setText(status)
        self.status.setStyleSheet(
            "font-size: 14px; font-weight: 600; color: "
            + (colour if lit else MUTED_INK if paused else INK) + ";")
        self.transport.setIcon(
            icon_play("#c3c7cd") if paused else icon_pause("#c3c7cd"))
        self.transport.setToolTip(
            _("Start listening") if paused else _("Pause listening"))


class UpdateBanner(QFrame):
    """
    The strip that appears above the dot when a new build exists.

    Sits at the top so it never covers the dot. A critical update loses its
    "Later" button but the dot keeps running — this is an insistence, not a
    lock.
    """

    def __init__(self, app, info, on_dismiss):
        super().__init__()
        self.app = app
        self.info = info
        self.on_dismiss = on_dismiss

        edge = "#FF8A6B" if info.critical else COLOURS[app.colour_index][1]
        self.setStyleSheet(
            "QFrame { background: #161b22; border: 2px solid " + edge + ";"
            " border-radius: 12px; }")

        box = QVBoxLayout(self)
        box.setContentsMargins(16, 14, 16, 14)
        box.setSpacing(6)

        title = QLabel(
            (_("Please update — version {}") if info.critical
             else _("Version {} is ready")).format(info.version))
        title.setStyleSheet(
            "font-size: 15px; font-weight: 600; border: none; color: "
            + (edge if info.critical else INK) + ";")
        box.addWidget(title)

        if info.notes:
            notes = QLabel("\n".join("•  " + n for n in info.notes))
            notes.setWordWrap(True)
            notes.setStyleSheet(
                "font-size: 12px; border: none; color: #9ba1a9;")
            box.addWidget(notes)

        self.detail = QLabel(_(
            "It will download, replace itself and restart. "
            "Your settings are kept."))
        self.detail.setWordWrap(True)
        self.detail.setStyleSheet("font-size: 11px; border: none; color: #7f858d;")
        box.addWidget(self.detail)

        row = QHBoxLayout()
        row.setSpacing(8)
        self.go = QPushButton(_("Update now"))
        self.go.setCursor(Qt.PointingHandCursor)
        self.go.setFixedHeight(38)
        self.go.setStyleSheet(
            "QPushButton { background: " + edge + "; color: #0b0e13;"
            " font-size: 14px; font-weight: 600; border: none;"
            " border-radius: 8px; padding: 0 18px; }")
        self.go.clicked.connect(self._install)
        row.addWidget(self.go)

        if not info.critical:
            later = QPushButton(_("Later"))
            later.setCursor(Qt.PointingHandCursor)
            later.setFixedHeight(38)
            later.setStyleSheet(
                "QPushButton { background: transparent; color: #8d929a;"
                " font-size: 13px; border: 1px solid #3a4048;"
                " border-radius: 8px; padding: 0 14px; }")
            later.clicked.connect(self._dismiss)
            row.addWidget(later)

        row.addStretch(1)
        box.addLayout(row)

    def _dismiss(self):
        self.app.settings.setValue("update_dismissed", self.info.version)
        self.on_dismiss()

    def _install(self):
        # Running from source has no .exe to replace, so the honest thing is
        # to hand the user the download page instead of pretending.
        if not updates.frozen():
            import webbrowser
            webbrowser.open(self.info.url)
            return

        self.go.setEnabled(False)
        self.go.setText(_("Downloading…"))
        self.detail.setText(_("Downloading…"))

        def progress(fraction):
            # Called from the worker thread; Qt text updates are queued.
            self.detail.setText(
                _("Downloading… {}%").format(int(fraction * 100)))

        def work():
            path = updates.download(self.info, progress)
            if not path:
                self.detail.setText(_("The download failed. Try again later."))
                self.go.setEnabled(True)
                self.go.setText(_("Update now"))
                return
            if updates.apply_and_restart(path):
                self.app.meter.stop()
                QApplication.quit()
            else:
                self.detail.setText(_("Could not install it. Try again later."))
                self.go.setEnabled(True)
                self.go.setText(_("Update now"))

        threading.Thread(target=work, daemon=True).start()


class FullScreen(QWidget):
    """The large dot. For a spare monitor, or a laptop parked on the table."""

    def __init__(self, app):
        super().__init__()
        self.app = app
        self.setWindowTitle("PDVoice Buddy")
        self.setStyleSheet("background: #05070a;")

        root = QVBoxLayout(self)
        root.setContentsMargins(0, 0, 0, 0)
        root.setSpacing(0)

        self.banner_host = QVBoxLayout()
        self.banner_host.setContentsMargins(24, 20, 24, 0)
        root.addLayout(self.banner_host)

        buttons = QHBoxLayout()
        buttons.setContentsMargins(18, 18, 18, 0)
        buttons.addStretch(1)
        self.transport = flat_button(46)
        self.transport.clicked.connect(app.toggle_paused)
        buttons.addWidget(self.transport)
        self.gear = flat_button(46)
        self.gear.setIcon(icon_gear("#9aa0a8"))
        self.gear.clicked.connect(app.open_settings)
        buttons.addWidget(self.gear)
        self.close_btn = flat_button(46, hover="#2a1f1d")
        self.close_btn.setIcon(icon_close("#7f858d"))
        self.close_btn.setToolTip(_("Hide — click the tray icon to bring it back"))
        self.close_btn.clicked.connect(app.hide_to_tray)
        buttons.addWidget(self.close_btn)
        root.addLayout(buttons)

        root.addStretch(1)
        centre = QHBoxLayout()
        centre.addStretch(1)
        self.dot = Dot(FULL_DOT)
        centre.addWidget(self.dot)
        centre.addStretch(1)
        root.addLayout(centre)

        self.status = QLabel(_("Listening to the room"))
        self.status.setAlignment(Qt.AlignCenter)
        self.status.setStyleSheet(
            "font-size: 30px; font-weight: 600; color: " + INK + ";")
        root.addSpacing(28)
        root.addWidget(self.status)
        root.addStretch(1)

        self.hint = QLabel(_("Click anywhere for settings   ·   Esc to hide"))
        self.hint.setAlignment(Qt.AlignCenter)
        self.hint.setStyleSheet("font-size: 12px; color: #5b6068;")
        root.addWidget(self.hint)
        root.addSpacing(22)

    def mousePressEvent(self, _event):
        self.app.open_settings()

    def keyPressEvent(self, event):
        if event.key() == Qt.Key_Escape:
            self.app.hide_to_tray()

    def show_update(self, info):
        """Replaces any existing banner. info=None clears it."""
        while self.banner_host.count():
            item = self.banner_host.takeAt(0)
            widget = item.widget()
            if widget is not None:
                widget.setParent(None)
        if info is not None:
            self.banner_host.addWidget(
                UpdateBanner(self.app, info, self.app.refresh_update_banner))

    def retranslate(self):
        self.setWindowTitle("PDVoice Buddy")
        self.hint.setText(_("Click anywhere for settings   ·   Esc to hide"))
        self.close_btn.setToolTip(
            _("Hide — click the tray icon to bring it back"))

    def apply(self, lit, level, paused, colour, status):
        self.dot.apply(lit, level, paused, colour)
        self.status.setText(status)
        self.status.setStyleSheet(
            "font-size: 30px; font-weight: 600; color: "
            + (colour if lit else MUTED_INK if paused else INK) + ";")
        self.transport.setIcon(
            icon_play("#c3c7cd") if paused else icon_pause("#c3c7cd"))


class Settings(QWidget):
    """
    Four things, and most people will only ever change the first.
    Every extra option is one more thing that can be set wrong and forgotten.
    """

    def __init__(self, app):
        super().__init__()
        self.app = app
        self.setWindowTitle(_("PDVoice Buddy — Settings"))
        self.setWindowFlags(Qt.Dialog)
        self.setFixedWidth(360)
        self.setStyleSheet("background: " + BG + ";")

        root = QVBoxLayout(self)
        root.setContentsMargins(22, 20, 22, 20)
        root.setSpacing(18)

        root.addWidget(self._heading(_("HOW LOUD YOU NEED TO BE")))
        self.effort_row = QHBoxLayout()
        self.effort_row.setSpacing(6)
        self.effort_buttons = []
        for i, (name, _note, _db) in enumerate(EFFORTS):
            b = QPushButton(_(name))
            b.setCursor(Qt.PointingHandCursor)
            b.setFixedHeight(34)
            b.clicked.connect(lambda _=False, idx=i: self.app.set_effort(idx))
            self.effort_row.addWidget(b)
            self.effort_buttons.append(b)
        root.addLayout(self.effort_row)
        self.effort_note = QLabel()
        self.effort_note.setWordWrap(True)
        self.effort_note.setStyleSheet("font-size: 11px; color: #868c94;")
        self.target_note = QLabel()
        self.target_note.setWordWrap(True)
        self.target_note.setStyleSheet("font-size: 11px; color: #6f757d;")
        root.addWidget(self.effort_note)
        root.addWidget(self.target_note)

        root.addWidget(self._heading(_("COLOUR")))
        colour_row = QHBoxLayout()
        colour_row.setSpacing(10)
        self.colour_buttons = []
        for i, (name, hex_code) in enumerate(COLOURS):
            b = QPushButton()
            b.setFixedSize(38, 38)
            b.setToolTip(_(name))
            b.setCursor(Qt.PointingHandCursor)
            b.clicked.connect(lambda _=False, idx=i: self.app.set_colour(idx))
            colour_row.addWidget(b)
            self.colour_buttons.append((b, hex_code))
        colour_row.addStretch(1)
        root.addLayout(colour_row)

        root.addWidget(self._heading(_("UPDATES")))
        self.version_label = QLabel(
            _("You have version {}").format(updates.VERSION))
        self.version_label.setStyleSheet(
            "font-size: 11px; color: " + MUTED_INK + ";")
        root.addWidget(self.version_label)
        self.update_button = QPushButton(_("Check now"))
        self.update_button.setCursor(Qt.PointingHandCursor)
        self.update_button.setFixedHeight(34)
        self.update_button.clicked.connect(self._update_clicked)
        root.addWidget(self.update_button)
        self._segment(self.update_button, False, "#8D929A", 12)

        root.addWidget(self._heading(_("MICROPHONE CALIBRATION")))
        self.calib_note = QLabel(_(
            "Only worth touching if the dot seems far too easy or far too "
            "hard everywhere. Speak normally at arm's length and compare "
            "with a sound level meter app."))
        self.calib_note.setWordWrap(True)
        self.calib_note.setStyleSheet(
            "font-size: 11px; color: " + MUTED_INK + ";")
        root.addWidget(self.calib_note)

        self.calib_now = QLabel("")
        self.calib_now.setStyleSheet(
            "font-family: Consolas, monospace; font-size: 16px; color: "
            + INK + ";")
        root.addWidget(self.calib_now)

        calib_row = QHBoxLayout()
        calib_row.setSpacing(6)
        for text, delta in ((_("−"), -1.0), (_("+"), 1.0)):
            b = QPushButton(text)
            b.setCursor(Qt.PointingHandCursor)
            b.setFixedHeight(34)
            b.setFixedWidth(54)
            b.clicked.connect(lambda _=False, d=delta: self.app.nudge_mic_offset(d))
            calib_row.addWidget(b)
            self._segment(b, False, "#8D929A", 15)
        reset = QPushButton(_("Reset"))
        reset.setCursor(Qt.PointingHandCursor)
        reset.setFixedHeight(34)
        reset.clicked.connect(self.app.reset_mic_offset)
        calib_row.addWidget(reset)
        self._segment(reset, False, "#8D929A", 12)
        calib_row.addStretch(1)
        root.addLayout(calib_row)

        # A live number, so it can be read against a separate meter app.
        self.calib_timer = QTimer(self)
        self.calib_timer.timeout.connect(self._refresh_calibration)
        self.calib_timer.start(200)

        root.addWidget(self._heading(_("LANGUAGE")))
        lang_row = QHBoxLayout()
        lang_row.setSpacing(6)
        self.lang_buttons = []
        for code, own_name in LANGUAGES:
            b = QPushButton(own_name or _("Automatic"))
            b.setCursor(Qt.PointingHandCursor)
            b.setFixedHeight(34)
            b.clicked.connect(lambda _=False, c=code: self.app.set_language(c))
            lang_row.addWidget(b)
            self.lang_buttons.append((code, b))
        root.addLayout(lang_row)

        root.addWidget(self._heading(_("SIZE")))
        shape_row = QHBoxLayout()
        shape_row.setSpacing(6)
        self.shape_buttons = []
        for i, label in ((SHAPE_FULL, "Full screen"), (SHAPE_PILL, "Small pill")):
            b = QPushButton(_(label))
            b.setCursor(Qt.PointingHandCursor)
            b.setFixedHeight(36)
            b.clicked.connect(lambda _=False, idx=i: self.app.set_shape(idx))
            shape_row.addWidget(b)
            self.shape_buttons.append(b)
        root.addLayout(shape_row)

        footer = QHBoxLayout()
        self.login = QPushButton()
        self.login.setCursor(Qt.PointingHandCursor)
        self.login.setFixedHeight(32)
        self.login.clicked.connect(self.app.toggle_login_item)
        footer.addWidget(self.login)
        footer.addStretch(1)
        quit_btn = QPushButton(_("Quit"))
        quit_btn.setCursor(Qt.PointingHandCursor)
        quit_btn.setFixedHeight(32)
        quit_btn.setStyleSheet(
            "QPushButton { border: 1px solid #3a4150; border-radius: 6px;"
            "padding: 0 14px; background: transparent; color: #c3c7cd;"
            "font-size: 11px; }"
            "QPushButton:hover { background: #3a2420; color: #ffb3a7; }")
        quit_btn.clicked.connect(self.app.quit_app)
        footer.addWidget(quit_btn)
        root.addSpacing(2)
        root.addLayout(footer)

        self.refresh()

    @staticmethod
    def _heading(text):
        label = QLabel(text)
        label.setStyleSheet(
            "font-size: 10px; letter-spacing: 1.4px; color: #8e939b;")
        return label

    def _update_clicked(self):
        info = self.app.update_info
        if info is not None:
            # Same path as the banner, so there is one install route only.
            banner = UpdateBanner(self.app, info, self.app.refresh_update_banner)
            banner._install()
            self.app.show_shape()
        else:
            self.app.check_for_updates_now()

    def _refresh_update(self):
        info = self.app.update_info
        if info is not None:
            self.version_label.setText(
                _("Version {} is ready").format(info.version))
            self.update_button.setText(_("Update now"))
            self._segment(self.update_button, True,
                          COLOURS[self.app.colour_index][1], 12)
        elif self.app._checking:
            self.version_label.setText(_("Checking…"))
        else:
            if self.app._checked_manually:
                self.version_label.setText(
                    _("You have version {} — this is the newest")
                    .format(updates.VERSION))
            else:
                self.version_label.setText(
                    _("You have version {}").format(updates.VERSION))
            self.update_button.setText(_("Check now"))
            self._segment(self.update_button, False, "#8D929A", 12)

    def _refresh_calibration(self):
        if not self.isVisible():
            return
        db = self.app.cue.db
        # Below this the reading is noise, and a number would imply a precision
        # the microphone does not have.
        if not self.app.meter.running or db < -70.0:
            self.calib_now.setText(_("Now: quiet"))
        else:
            self.calib_now.setText(
                _("Now: about {} dB").format(int(self.app.spl_of(db)))
                + "   ·   "
                + _("bar {} dB").format(int(EFFORTS[self.app.effort_index][3])))

    def refresh(self):
        accent = COLOURS[self.app.colour_index][1]
        for i, b in enumerate(self.effort_buttons):
            self._segment(b, i == self.app.effort_index, accent, 10)
        name, note, _db = EFFORTS[self.app.effort_index]
        self.effort_note.setText(
            _(name) + " — " + _(note)
            + _(". If the dot is dark most of the time, go down a step."))
        self._refresh_update()
        self.target_note.setText(_(
            "Normal conversation is 60–70 dB. The dot needs your voice above "
            "the room AND above this level, so a quiet room no longer lets a "
            "whisper through."))
        for i, (b, hex_code) in enumerate(self.colour_buttons):
            on = i == self.app.colour_index
            b.setStyleSheet(
                "QPushButton { border-radius: 19px; background: " + hex_code + ";"
                " border: " + ("3px solid #ffffff" if on else "1px solid #2b313c")
                + "; }")
        for i, b in enumerate(self.shape_buttons):
            self._segment(b, i == self.app.shape, accent, 11)
        for code, b in self.lang_buttons:
            self._segment(b, code == self.app.language, accent, 11)
        self.login.setText(
            ("✓  " if login_item_enabled() else "") + _("Open at login"))
        self._segment(self.login, login_item_enabled(), accent, 11)
        self.adjustSize()

    @staticmethod
    def _segment(button, on, accent, size):
        if on:
            button.setStyleSheet(
                "QPushButton { border-radius: 6px; background: " + accent + ";"
                " border: none; color: #10261a; font-size: " + str(size) + "px;"
                " font-weight: 600; padding: 0 8px; }")
        else:
            button.setStyleSheet(
                "QPushButton { border-radius: 6px; background: transparent;"
                " border: 1px solid #3a4150; color: #c3c7cd; font-size: "
                + str(size) + "px; padding: 0 8px; }"
                "QPushButton:hover { background: #1b2028; }")


# ------------------------------------------------------------------- app ----


class Buddy:
    """Holds the model, the windows, and the tray icon."""

    def __init__(self):
        self.settings = QSettings("PDVoiceBuddy", "PDVoice Buddy")
        self.effort_index = int(self.settings.value("effort", 2))
        self.colour_index = int(self.settings.value("colour", 0))
        self.shape = int(self.settings.value("shape", SHAPE_PILL))
        self.paused = False

        self.language = str(self.settings.value("language", LANG_AUTO))
        for arg in sys.argv[1:]:
            if arg.startswith("--lang="):
                # A test switch: overrides the setting for this run only.
                self.language = arg.split("=", 1)[1].lower()
        set_language(self.language)

        self.mic_offset = float(
            self.settings.value("mic_offset", DEFAULT_MIC_OFFSET))
        self.cue = VoiceCue(
            margin_db=EFFORTS[self.effort_index][2],
            target_dbfs=self._target_dbfs(),
        )
        self.meter = Meter(self.cue)

        self.pill = Pill(self)
        self.full = FullScreen(self)
        self.settings_window = None
        self.update_info = None
        self._build_tray()

        # Once a day, quietly. The callback lands on a worker thread, so it
        # only stores the result and asks Qt to redraw on its own timer.
        updates.check_in_background(self.settings, on_done=self._update_found)

        self.pill.place_default()
        self.show_shape()
        self.meter.start()

        self.timer = QTimer()
        self.timer.timeout.connect(self.render)
        self.timer.start(RENDER_MS)
        self.render()

    # ------------------------------------------------------------ windows --

    @property
    def window(self):
        return self.pill if self.shape == SHAPE_PILL else self.full

    def show_shape(self):
        """Only ever one on screen — the two can never end up stacked."""
        if self.shape == SHAPE_PILL:
            self.full.hide()
            self.pill.show()
            self.pill.raise_()
        else:
            self.pill.hide()
            self.full.showFullScreen()
            self.full.raise_()

    def hide_to_tray(self):
        # Make certain there is a way back before disappearing. On the desktop
        # the ✕ hides rather than quits — that is the platform norm, and Quit
        # is one click away in settings and the tray menu.
        self.tray.show()
        if not self.tray.isVisible():
            return
        self.pill.hide()
        self.full.hide()
        if not self.settings.value("told_about_tray", False):
            self.tray.showMessage(
                _("PDVoice Buddy is still listening"),
                _("Click this icon to bring it back. Right-click it for Quit."),
                QSystemTrayIcon.Information, 6000)
            self.settings.setValue("told_about_tray", True)

    def _update_found(self, info):
        """Called from the update thread. Stores only; the UI reads it later."""
        if info is None:
            return
        dismissed = str(self.settings.value("update_dismissed", "") or "")
        if not info.critical and dismissed == info.version:
            return
        self.update_info = info
        self._banner_dirty = True

    def refresh_update_banner(self):
        """Puts the banner where it belongs, or takes it away."""
        info = self.update_info
        if info is not None:
            dismissed = str(self.settings.value("update_dismissed", "") or "")
            if not info.critical and dismissed == info.version:
                info = None
                self.update_info = None
        self.full.show_update(info)
        # The pill is too small for a banner, so a tray balloon carries it.
        if info is not None and self.shape == SHAPE_PILL:
            if str(self.settings.value("update_told", "")) != info.version:
                self.settings.setValue("update_told", info.version)
                self.tray.showMessage(
                    _("Version {} is ready").format(info.version),
                    _("Open PDVoice Buddy settings to install it."),
                    QSystemTrayIcon.Information, 8000)
        if self.settings_window is not None:
            self.settings_window.refresh()

    def check_for_updates_now(self):
        """The Check now button. Forces a fetch regardless of the daily rule."""
        def done(info):
            self._update_found(info)
            self._banner_dirty = True
            self._checked_manually = True
        self._checking = True
        updates.check_in_background(self.settings, force=True, on_done=done)
        if self.settings_window is not None:
            self.settings_window.refresh()

    def open_settings(self):
        if self.settings_window is None:
            self.settings_window = Settings(self)
        self.settings_window.refresh()
        self.settings_window.show()
        self.settings_window.raise_()
        self.settings_window.activateWindow()

    # ----------------------------------------------------------- controls --

    def toggle_paused(self):
        self.paused = not self.paused
        if self.paused:
            self.meter.stop()
        else:
            self.meter.start()
        self.pause_action.setText(
            _("Start listening") if self.paused else _("Pause listening"))
        self.render()

    def set_effort(self, index):
        self.effort_index = max(0, min(len(EFFORTS) - 1, index))
        self.settings.setValue("effort", self.effort_index)
        self.cue.margin_db = EFFORTS[self.effort_index][2]
        self.cue.target_dbfs = self._target_dbfs()
        if self.settings_window:
            self.settings_window.refresh()
        self.render()

    def set_language(self, choice):
        if choice == self.language:
            return
        self.language = choice
        self.settings.setValue("language", choice)
        set_language(choice)
        self._relabel()

    def _relabel(self):
        """Rebuild every piece of visible text in the new language."""
        self._build_tray_menu(rebuild=True)
        for window in (self.pill, self.full):
            window.retranslate()
        if self.settings_window:
            was_open = self.settings_window.isVisible()
            self.settings_window.close()
            self.settings_window = None
            if was_open:
                self.open_settings()
        self.render()

    def _target_dbfs(self):
        """The absolute bar in dBFS, which is what VoiceCue works in."""
        return EFFORTS[self.effort_index][3] - self.mic_offset

    def spl_of(self, dbfs):
        """Raw dBFS as the approximate SPL shown on screen."""
        return dbfs + self.mic_offset

    def nudge_mic_offset(self, by):
        self.mic_offset = max(70.0, min(120.0, self.mic_offset + by))
        self.settings.setValue("mic_offset", self.mic_offset)
        self.cue.target_dbfs = self._target_dbfs()
        if self.settings_window:
            self.settings_window.refresh()

    def reset_mic_offset(self):
        self.mic_offset = DEFAULT_MIC_OFFSET
        self.settings.setValue("mic_offset", self.mic_offset)
        self.cue.target_dbfs = self._target_dbfs()
        if self.settings_window:
            self.settings_window.refresh()

    def set_colour(self, index):
        self.colour_index = max(0, min(len(COLOURS) - 1, index))
        self.settings.setValue("colour", self.colour_index)
        self._icon_cache = None
        if self.settings_window:
            self.settings_window.refresh()
        self.render()

    def set_shape(self, shape):
        self.shape = shape
        self.settings.setValue("shape", shape)
        self.show_shape()
        if self.settings_window:
            self.settings_window.refresh()
        self.render()

    def toggle_login_item(self):
        set_login_item(not login_item_enabled())
        if self.settings_window:
            self.settings_window.refresh()
        self.login_action.setChecked(login_item_enabled())

    def quit_app(self):
        self.meter.stop()
        QApplication.quit()

    # -------------------------------------------------------------- render --

    def _status(self):
        if self.paused:
            return _("Paused")
        if self.meter.error:
            return _("No microphone")
        if not self.meter.running:
            return _("Starting up")
        if not self.cue.ready:
            return _("Listening to the room")
        return _("Heard") if self.cue.lit else _("Louder")

    _banner_dirty = False
    _checking = False
    _checked_manually = False

    def render(self):
        if self._banner_dirty:
            self._banner_dirty = False
            self._checking = False
            self.refresh_update_banner()

        colour = COLOURS[self.colour_index][1]
        lit = self.cue.lit and not self.paused and self.meter.running
        level = 0.0 if self.paused else self.cue.level
        status = self._status()
        self.window.apply(lit, level, self.paused, colour, status)

        key = "paused" if self.paused else ("lit" if lit else "dim")
        if key != getattr(self, "_tray_state", None):
            self._tray_state = key
            self.tray.setIcon(self._tray_icon())

    # ---------------------------------------------------------------- tray --

    def _build_tray(self):
        self.tray = QSystemTrayIcon()
        self._tray_state = "dim"
        self.tray.setIcon(self._tray_icon())
        self._build_tray_menu()
        self.tray.activated.connect(self._tray_clicked)
        self.tray.show()

    def _build_tray_menu(self, rebuild=False):
        """The menu only. Replacing the icon itself makes Windows drop it."""
        self.tray.setToolTip(_("PDVoice Buddy — click to show or hide"))
        menu = QMenu()
        menu.addAction(_("Show"), self.show_shape)
        menu.addAction(_("Hide"), self.hide_to_tray)
        self.pause_action = menu.addAction(_("Pause listening"), self.toggle_paused)
        menu.addSeparator()
        menu.addAction(_("Settings…"), self.open_settings)
        self.login_action = menu.addAction(_("Open at login"), self.toggle_login_item)
        self.login_action.setCheckable(True)
        self.login_action.setChecked(login_item_enabled())
        menu.addSeparator()
        menu.addAction(_("Quit PDVoice Buddy"), self.quit_app)
        self.tray.setContextMenu(menu)
        self.menu = menu                      # keep a reference alive
        if self.paused:
            self.pause_action.setText(_("Start listening"))

    def _tray_clicked(self, reason):
        if reason in (QSystemTrayIcon.Trigger, QSystemTrayIcon.DoubleClick):
            if self.window.isVisible():
                self.hide_to_tray()
            else:
                self.show_shape()

    def _icon_from_file(self):
        here = Path(__file__).resolve().parent
        candidate = here / "tray.png"
        if not candidate.exists():                     # frozen by PyInstaller
            candidate = Path(getattr(sys, "_MEIPASS", here)) / "tray.png"
        if candidate.exists():
            icon = QIcon(str(candidate))
            if not icon.isNull():
                return icon
        return None

    def _make_icon(self, colour):
        pix = _pix(64)
        p = QPainter(pix)
        p.setRenderHint(QPainter.Antialiasing)
        p.setPen(Qt.NoPen)
        p.setBrush(QColor(colour))
        p.drawEllipse(QPointF(32, 32), 20, 20)
        p.end()
        return QIcon(pix)

    def _tray_icon(self):
        """Cached — Windows drops the tray icon if you replace it constantly."""
        if getattr(self, "_icon_cache", None) is None:
            from_file = self._icon_from_file()
            self._icon_cache = {
                "lit": from_file or self._make_icon(COLOURS[self.colour_index][1]),
                "dim": from_file or self._make_icon(DIM),
                "paused": from_file or self._make_icon(DIM_PAUSED),
            }
        return self._icon_cache[getattr(self, "_tray_state", "dim")]


# ------------------------------------------------------- open-at-login glue ---

LAUNCH_AGENT = Path.home() / "Library/LaunchAgents/com.pdvoicebuddy.app.plist"
RUN_KEY = r"Software\Microsoft\Windows\CurrentVersion\Run"


def login_item_enabled():
    if platform.system() == "Darwin":
        return LAUNCH_AGENT.exists()
    if platform.system() == "Windows":
        import winreg
        try:
            with winreg.OpenKey(winreg.HKEY_CURRENT_USER, RUN_KEY) as key:
                winreg.QueryValueEx(key, "PDVoiceBuddy")
            return True
        except OSError:
            return False
    return False


def set_login_item(enabled):
    target = sys.executable
    script = str(Path(__file__).resolve())

    if platform.system() == "Darwin":
        if enabled:
            LAUNCH_AGENT.parent.mkdir(parents=True, exist_ok=True)
            LAUNCH_AGENT.write_text(
                '<?xml version="1.0" encoding="UTF-8"?>\n'
                '<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN" '
                '"http://www.apple.com/DTDs/PropertyList-1.0.dtd">\n'
                '<plist version="1.0"><dict>'
                "<key>Label</key><string>com.pdvoicebuddy.app</string>"
                f"<key>ProgramArguments</key><array><string>{target}</string>"
                f"<string>{script}</string></array>"
                "<key>RunAtLoad</key><true/>"
                "</dict></plist>\n"
            )
        elif LAUNCH_AGENT.exists():
            LAUNCH_AGENT.unlink()

    elif platform.system() == "Windows":
        import winreg
        with winreg.OpenKey(winreg.HKEY_CURRENT_USER, RUN_KEY, 0,
                            winreg.KEY_SET_VALUE) as key:
            if enabled:
                winreg.SetValueEx(key, "PDVoiceBuddy", 0, winreg.REG_SZ,
                                  f'"{target}" "{script}"')
            else:
                try:
                    winreg.DeleteValue(key, "PDVoiceBuddy")
                except OSError:
                    pass


# -------------------------------------------------------------------- main ---


def main():
    app = QApplication(sys.argv)
    app.setApplicationName("PDVoice Buddy")
    app.setQuitOnLastWindowClosed(False)
    buddy = Buddy()                          # keep a reference alive
    app.buddy = buddy
    sys.exit(app.exec())


if __name__ == "__main__":
    main()
