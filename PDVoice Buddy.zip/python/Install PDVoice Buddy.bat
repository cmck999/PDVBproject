@echo off
REM PDVoice Buddy - double-click installer for Windows.
REM Sets up everything, makes a Desktop shortcut, and starts the app.

cd /d "%~dp0"
echo.
echo   PDVoice Buddy - installing
echo   ---------------------------------------
echo.

REM --- 1. Python -------------------------------------------------------------

where python >nul 2>nul
if errorlevel 1 goto NOPYTHON

for /f "tokens=*" %%v in ('python --version 2^>^&1') do echo   [ok] Found %%v

REM --- 2. Dependencies -------------------------------------------------------

if not exist ".venv" (
  echo   . Creating a private environment for the app...
  python -m venv .venv
)

echo   . Downloading what it needs ^(takes a minute the first time^)...
".venv\Scripts\python.exe" -m pip install --quiet --upgrade pip
".venv\Scripts\python.exe" -m pip install --quiet -r requirements.txt
if errorlevel 1 goto FAILED

echo   [ok] Ready

REM --- 3. One-click launcher -------------------------------------------------

> "PDVoice Buddy.bat" echo @echo off
>> "PDVoice Buddy.bat" echo cd /d "%~dp0"
>> "PDVoice Buddy.bat" echo start "" ".venv\Scripts\pythonw.exe" pdvoice_buddy.py

powershell -NoProfile -Command ^
  "$s=(New-Object -ComObject WScript.Shell).CreateShortcut(\"$env:USERPROFILE\Desktop\PDVoice Buddy.lnk\"); $s.TargetPath='%CD%\PDVoice Buddy.bat'; $s.WorkingDirectory='%CD%'; $s.Save()" >nul 2>nul

echo   [ok] Put 'PDVoice Buddy' on your Desktop

echo.
echo   ---------------------------------------
echo   Done. Starting it now.
echo.
echo   Windows may ask for microphone access.
echo   Click Yes - nothing is ever recorded.
echo.
echo   From now on, just double-click PDVoice Buddy
echo   on your Desktop.
echo.

REM --- 4. Go -----------------------------------------------------------------

start "" ".venv\Scripts\pythonw.exe" pdvoice_buddy.py
timeout /t 3 >nul
exit /b 0

:NOPYTHON
echo   Python isn't installed yet.
echo.
echo   1. Go to  https://www.python.org/downloads/
echo   2. Download Python for Windows and run it
echo   3. IMPORTANT: tick "Add python.exe to PATH" on the first screen
echo   4. Then double-click this installer again
echo.
pause
exit /b 1

:FAILED
echo.
echo   Something went wrong installing the dependencies.
echo   Send the text above to whoever set this up.
echo.
pause
exit /b 1
