@echo off
REM Use this one if the app won't start. It shows the error instead of vanishing.
cd /d "%~dp0"
echo.
echo   Starting PDVoice Buddy with errors visible...
echo   ------------------------------------------------
echo.

REM Find a Python. Prefer the .venv beside this file, then one folder up,
REM then whatever Python is installed on the system.
set "PY="
if exist ".venv\Scripts\python.exe" set "PY=.venv\Scripts\python.exe"
if not defined PY if exist "..\.venv\Scripts\python.exe" set "PY=..\.venv\Scripts\python.exe"
if not defined PY if exist "..\..\.venv\Scripts\python.exe" set "PY=..\..\.venv\Scripts\python.exe"
if not defined PY if exist "..\..\..\.venv\Scripts\python.exe" set "PY=..\..\..\.venv\Scripts\python.exe"
if not defined PY (
  where py >nul 2>nul && set "PY=py"
)
if not defined PY (
  where python >nul 2>nul && set "PY=python"
)

if not defined PY (
  echo   Could not find Python on this computer.
  echo   Install it from python.org, then run this again.
  echo.
  pause
  exit /b
)

echo   Using: %PY%
echo.
%PY% "pdvoice_buddy.py"

echo.
echo   ------------------------------------------------
echo   The app has closed.
echo   If there is red text above, copy it and send it over.
echo.
pause
