"""
Checking GitHub Releases for a newer build, and installing it.

Unlike Android, Windows lets a program replace itself. The trick is that a
running .exe is locked, so it cannot overwrite its own file. The standard
answer, used here:

    1. Download the new .exe beside the old one, under a temporary name.
    2. Verify its SHA-256 against the manifest. This matters — the file is
       fetched over the network and then executed.
    3. Write a small batch script that waits for this process to exit,
       swaps the files, relaunches, and deletes itself.
    4. Start the script and quit.

Deliberate limits:

  - Nothing downloads without the user pressing a button. No silent updates:
    a tool someone relies on should not change under them unannounced.
  - A critical update is an insistent banner, never a lock. Disabling the
    voice cue to force an upgrade would punish the person for the
    developer's mistake.
  - Every failure is silent or a single plain sentence. An update check is
    not worth a stack trace in front of a patient.
"""

import hashlib
import json
import os
import subprocess
import sys
import tempfile
import threading
import time
import urllib.request

# The manifest, on the default branch of the project repository. This is the
# raw.githubusercontent.com address, NOT the github.com page address — the page
# would return HTML. Change only if the repository is renamed or its default
# branch stops being "main".
MANIFEST_URL = "https://raw.githubusercontent.com/cmck999/PDVBproject/main/latest.json"

# Bump on every release and match it in latest.json.
VERSION = "0.4"

DAY_SECONDS = 24 * 60 * 60
TIMEOUT = 8


def _parts(version):
    """"0.4.1" -> (0, 4, 1), so versions compare numerically not as text."""
    out = []
    for chunk in str(version).split("."):
        digits = "".join(c for c in chunk if c.isdigit())
        out.append(int(digits) if digits else 0)
    return tuple(out)


def is_newer(candidate, current=VERSION):
    return _parts(candidate) > _parts(current)


class UpdateInfo:
    def __init__(self, version, url, sha256, notes, critical):
        self.version = version
        self.url = url
        self.sha256 = (sha256 or "").lower().strip()
        self.notes = notes or []
        self.critical = critical


def fetch(timeout=TIMEOUT):
    """The manifest, or None. Never raises."""
    try:
        request = urllib.request.Request(
            MANIFEST_URL, headers={"Accept": "application/json"})
        with urllib.request.urlopen(request, timeout=timeout) as response:
            data = json.loads(response.read().decode("utf-8"))
        block = data["windows"]
        latest = str(block["version"])
        min_supported = str(block.get("minSupportedVersion", "0"))
        return UpdateInfo(
            version=latest,
            url=block["url"],
            sha256=block.get("sha256", ""),
            notes=list(block.get("notes", [])),
            # Below the supported floor: this build should not stay in use.
            critical=is_newer(min_supported, VERSION),
        )
    except Exception:
        return None       # Silent by design. Tries again tomorrow.


def check_in_background(settings, force=False, on_done=None):
    """
    Fetches at most once a day unless forced.

    on_done is called from the worker thread with the UpdateInfo or None; Qt
    callers must marshal back to the GUI thread themselves.
    """
    last = float(settings.value("update_checked", 0) or 0)
    if not force and (time.time() - last) < DAY_SECONDS:
        if on_done:
            on_done(None)
        return
    # Recorded before the attempt, so a server that is down cannot cause a
    # check on every launch.
    settings.setValue("update_checked", time.time())

    def work():
        info = fetch()
        if info is not None and not is_newer(info.version):
            info = None
        if on_done:
            on_done(info)

    threading.Thread(target=work, daemon=True).start()


def frozen():
    """True when running as the built .exe rather than from source."""
    return getattr(sys, "frozen", False)


def download(info, progress=None):
    """
    The new .exe as a temporary file path, or None.

    Verifies SHA-256 when the manifest supplies one, and refuses the file if
    it does not match. Executing an unverified download would be careless.
    """
    try:
        target = os.path.join(
            tempfile.gettempdir(), "PDVoiceBuddy-%s.exe.part" % info.version)
        digest = hashlib.sha256()
        request = urllib.request.Request(
            info.url, headers={"User-Agent": "PDVoiceBuddy/%s" % VERSION})
        with urllib.request.urlopen(request, timeout=30) as response:
            total = int(response.headers.get("Content-Length") or 0)
            done = 0
            with open(target, "wb") as handle:
                while True:
                    chunk = response.read(65536)
                    if not chunk:
                        break
                    handle.write(chunk)
                    digest.update(chunk)
                    done += len(chunk)
                    if progress and total:
                        progress(done / total)

        if info.sha256 and digest.hexdigest().lower() != info.sha256:
            os.remove(target)
            return None
        return target
    except Exception:
        return None


def apply_and_restart(new_exe):
    """
    Swaps the running .exe for the downloaded one and relaunches.

    Returns False if this is not a frozen build, in which case there is
    nothing to replace and the caller should just open the download page.
    """
    if not frozen():
        return False
    try:
        current = os.path.abspath(sys.executable)
        backup = current + ".old"
        script = os.path.join(
            tempfile.gettempdir(), "pdvoicebuddy-update.bat")

        # ping is the portable way to sleep in a .bat. The loop waits for the
        # lock on the running exe to clear rather than guessing a duration.
        with open(script, "w", encoding="ascii") as handle:
            handle.write(
                '@echo off\r\n'
                'set EXE="%s"\r\n' % current +
                'set NEW="%s"\r\n' % new_exe +
                'set OLD="%s"\r\n' % backup +
                ':wait\r\n'
                'ping -n 2 127.0.0.1 >nul\r\n'
                'del %OLD% >nul 2>&1\r\n'
                'move /y %EXE% %OLD% >nul 2>&1\r\n'
                'if exist %EXE% goto wait\r\n'
                'move /y %NEW% %EXE% >nul 2>&1\r\n'
                'if not exist %EXE% (\r\n'
                '  move /y %OLD% %EXE% >nul 2>&1\r\n'
                ')\r\n'
                'start "" %EXE%\r\n'
                'del %OLD% >nul 2>&1\r\n'
                'del "%~f0" >nul 2>&1\r\n'
            )

        subprocess.Popen(
            ["cmd", "/c", script],
            creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0),
            close_fds=True,
        )
        return True
    except Exception:
        return False
