@echo off
REM Builds PDVoice Buddy.exe. Double-click this; it does everything.
cd /d "%~dp0"
echo.
echo   Building PDVoice Buddy.exe
echo   ------------------------------------------------
echo.

set "PY="
if exist ".venv\Scripts\python.exe" set "PY=.venv\Scripts\python.exe"
if not defined PY if exist "..\.venv\Scripts\python.exe" set "PY=..\.venv\Scripts\python.exe"
if not defined PY if exist "..\..\.venv\Scripts\python.exe" set "PY=..\..\.venv\Scripts\python.exe"
if not defined PY if exist "..\..\..\.venv\Scripts\python.exe" set "PY=..\..\..\.venv\Scripts\python.exe"
if not defined PY (
  where py >nul 2>nul && set "PY=py"
)
if not defined PY (
  where python >nul 2>nul && set "PY=python"
)
if not defined PY (
  echo   Could not find Python. Install it from python.org and try again.
  echo.
  pause
  exit /b
)

echo   Using: %PY%
echo.

REM A running copy of the app locks its own .exe, and PyInstaller then fails
REM with "Access is denied" at the very last step. Close it first.
tasklist /fi "imagename eq PDVoice Buddy.exe" 2>nul | find /i "PDVoice Buddy.exe" >nul
if not errorlevel 1 (
  echo   PDVoice Buddy is running - closing it so the file can be replaced.
  taskkill /f /im "PDVoice Buddy.exe" >nul 2>nul
  REM Give Windows a moment to actually release the file.
  ping -n 3 127.0.0.1 >nul
  echo.
)

echo   Step 1 of 2 - fetching the build tool...
%PY% -m pip install --quiet --upgrade pyinstaller PySide6 sounddevice numpy
if errorlevel 1 (
  echo.
  echo   Could not install the build tools. Check your internet connection.
  echo.
  pause
  exit /b
)

echo   Step 2 of 2 - building. This takes 1-3 minutes. Lots of text is normal.
echo.
%PY% -m PyInstaller --noconsole --noconfirm --onefile --name "PDVoice Buddy" pdvoice_buddy.py
if errorlevel 1 (
  echo.
  echo   The build failed.
  echo.
  echo   If the last line says "Access is denied", the app is still running
  echo   somewhere. Look for the PDVoice Buddy icon near your clock - click
  echo   the small arrow to see hidden icons - right-click it, choose Quit,
  echo   then run this again.
  echo.
  echo   Otherwise, copy the red text above and send it over.
  echo.
  pause
  exit /b
)

echo.
echo   ------------------------------------------------
echo   Done.
echo.
echo   Your app is:  dist\PDVoice Buddy.exe
echo.
echo   That single file is the whole app - you can copy it
echo   to any Windows computer and double-click it.
echo.
pause
start "" "dist"
