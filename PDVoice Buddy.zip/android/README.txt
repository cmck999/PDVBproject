PDVoice Buddy — Android
=======================

Phase 1 is the point of this project: prove the measurement model works
before building anything around it.


-----------------------------------------------------------------------------
OPEN IT
-----------------------------------------------------------------------------

Android Studio -> File -> Open -> select the "android" folder (not the
project root, not the "app" folder).

Let it sync. The first sync downloads Gradle and takes a few minutes. If it
complains about a missing Gradle wrapper, choose "Use Gradle from: Gradle
wrapper" or let Studio regenerate it — the properties file is already here.

No tablet needed yet.


-----------------------------------------------------------------------------
RUN PHASE 1 — THE TESTS
-----------------------------------------------------------------------------

In the project tree, open:

    app/src/test/java/com/pdvoicebuddy/VoiceCueTest.kt

Right-click the file -> Run 'VoiceCueTest'.

Nine tests run on your PC in about a second. No tablet, no emulator, no
permissions. If they pass, the model is sound.

The one that matters most is:

    a louder room demands a louder voice

It takes one fixed voice level and shows it passing in a quiet kitchen and
failing in a restaurant — which is the entire argument for this design over
the fixed-decibel approach the Windows version uses.

Also worth reading:

    the absolute scale is irrelevant
        The same 20 dB gap gives the same verdict whether the tablet is close
        or across the room. This is why there is no calibration constant
        anywhere in the engine.

    talking does not raise the room estimate much
        If speech dragged the room estimate upward, the cue would slowly go
        blind during a long conversation. This proves it doesn't.

    steady noise raises the bar rather than triggering
        A dishwasher must not light the ring.

Try breaking them. Change marginDb in VoiceCue.kt from 12f to 4f and watch
"steady noise raises the bar" fail — that tells you the margin is doing real
work, not decoration.


-----------------------------------------------------------------------------
WHAT'S IN HERE
-----------------------------------------------------------------------------

VoiceCue.kt          The engine. Pure Kotlin, no Android imports at all.
                     This is the file that becomes a library later, and the
                     only one worth arguing about.

VoiceCueTest.kt      Phase 1. Nine tests, runnable on the PC.

MeterService.kt      Holds the microphone. Requests the UNPROCESSED audio
                     source so Android's automatic gain control doesn't
                     flatten the differences we're measuring.

RingView.kt          The whole interface. One ring that swells and glows.

MainActivity.kt      The ring as a normal screen. Marked showWhenLocked, so
                     it appears without unlocking.

BuddyDream.kt        The ring as a screensaver — starts by itself when the
                     tablet is docked or charging.


-----------------------------------------------------------------------------
PHASE 2 — ON THE TABLET
-----------------------------------------------------------------------------

Only once the tests pass.

1. On the tablet: Settings -> About -> tap the build number seven times.
2. Settings -> Developer options -> enable Wireless debugging (easier than a
   cable for a tablet). Pair it with the QR code from Android Studio's
   Device Manager.
3. Press Run. First build takes 15-20 minutes.
4. Allow the microphone and notifications when asked.
5. Settings -> Display -> Screen saver -> pick PDVoice Buddy.
6. Put the tablet on a charging stand. The ring should appear on its own.

Then talk. Ring bright mint = carrying. Dim = louder.


-----------------------------------------------------------------------------
KNOWN GAPS
-----------------------------------------------------------------------------

No pause control on screen yet. The notification is the only way to stop it
short of killing the app.

No daily history — the percentage resets when the service restarts.

No driving mode. The spec says this must be handled in code (detect the car,
force buzz-only, screen dark) and it is not built. Do not put this in a
driver's eyeline as it stands.

No vibration. Walking is unsupported for now.

Battery is untested. A bright ring with the screen awake is expensive; expect
to want it plugged in.


Not a medical device. The margin should be set with a speech-language
pathologist, not guessed.
