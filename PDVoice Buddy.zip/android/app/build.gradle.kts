import java.io.FileInputStream
import java.util.Properties

plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

// Signing details live outside the build file so passwords never end up in a
// shared folder. See keystore.properties.example.
val keystoreProps = Properties()
val keystoreFile = rootProject.file("keystore.properties")
if (keystoreFile.exists()) {
    FileInputStream(keystoreFile).use { keystoreProps.load(it) }
}

android {
    namespace = "com.pdvoicebuddy"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.pdvoicebuddy"
        minSdk = 27
        targetSdk = 35
        // Bump BOTH on every release, and match them in latest.json.
        // versionCode is what the update check compares; it must only rise.
        versionCode = 4
        versionName = "0.4"
    }

    signingConfigs {
        if (keystoreProps.getProperty("storeFile") != null) {
            create("release") {
                storeFile = file(keystoreProps.getProperty("storeFile"))
                storePassword = keystoreProps.getProperty("storePassword")
                keyAlias = keystoreProps.getProperty("keyAlias")
                keyPassword = keystoreProps.getProperty("keyPassword")
            }
        }
    }

    buildTypes {
        release {
            isMinifyEnabled = false
            isDebuggable = false
            if (keystoreProps.getProperty("storeFile") != null) {
                signingConfig = signingConfigs.getByName("release")
            }
        }
    }

    // One clearly-named file per build, so testers can tell versions apart.
    applicationVariants.all {
        outputs.all {
            (this as com.android.build.gradle.internal.api.BaseVariantOutputImpl)
                .outputFileName = "PDVoiceBuddy-$versionName-$name.apk"
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }

    kotlinOptions {
        jvmTarget = "17"
    }
}

dependencies {
    testImplementation("junit:junit:4.13.2")
}
