package com.pdvoicebuddy

import android.content.Context
import android.content.Intent
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RadialGradient
import android.graphics.Shader
import android.graphics.Typeface
import android.view.MotionEvent
import android.view.View

/**
 * The entire interface: one glowing dot.
 *
 * A dot rather than a ring because a filled disc reads as a single light in
 * peripheral vision, where an outline reads as a shape you have to look at.
 *
 * Two kinds of smoothing, both necessary:
 *  - the displayed level chases the measured one, so the dot never jitters
 *    frame to frame the way raw RMS does;
 *  - it rises quickly and falls slowly, so a syllable brightens it at once
 *    but a gap between words barely dents it.
 *
 * @param allowSettings false inside the screensaver, where any touch exits.
 */
class RingView(
    context: Context,
    private val allowSettings: Boolean = true
) : View(context) {

    private val core = Paint(Paint.ANTI_ALIAS_FLAG)
    private val halo = Paint(Paint.ANTI_ALIAS_FLAG)
    private val title = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        textAlign = Paint.Align.CENTER
        typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
    }
    private val sub = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        textAlign = Paint.Align.CENTER
        typeface = Typeface.MONOSPACE
    }
    private val hint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        textAlign = Paint.Align.CENTER
        typeface = Typeface.MONOSPACE
    }

    private val dim = Color.parseColor("#39404A")
    private val paper = Color.parseColor("#C8CCD2")
    private val quiet = Color.parseColor("#7F858D")
    private val backdrop = Color.parseColor("#0B0E13")

    private var shownLevel = 0f
    private var shownLit = 0f
    private var haloShader: RadialGradient? = null
    private var haloRadius = 0f
    private var haloColour = 0

    private val frame = object : Runnable {
        override fun run() {
            invalidate()
            postDelayed(this, 16L)
        }
    }

    override fun onAttachedToWindow() {
        super.onAttachedToWindow()
        post(frame)
    }

    override fun onDetachedFromWindow() {
        removeCallbacks(frame)
        super.onDetachedFromWindow()
    }

    private val pauseRect = android.graphics.RectF()
    private val gearRect = android.graphics.RectF()
    private val iconRect = android.graphics.RectF()
    private val iconPath = android.graphics.Path()
    private val icon = Paint(Paint.ANTI_ALIAS_FLAG)

    override fun onTouchEvent(event: MotionEvent): Boolean {
        if (!allowSettings) return false
        if (event.action == MotionEvent.ACTION_UP) {
            if (pauseRect.contains(event.x, event.y)) {
                MeterService.setPaused(!MeterService.paused)
            } else {
                // The gear is explicit; anywhere else does the same thing.
                context.startActivity(Intent(context, SettingsActivity::class.java))
            }
            return true
        }
        return true
    }

    private fun chase(current: Float, target: Float, rise: Float, fall: Float): Float {
        val rate = if (target > current) rise else fall
        val next = current + (target - current) * rate
        return if (kotlin.math.abs(target - next) < 0.001f) target else next
    }

    override fun onDraw(canvas: Canvas) {
        canvas.drawColor(backdrop)

        val accent = Prefs.colour(context)
        val pill = Prefs.shape(context) == Prefs.SHAPE_PILL

        val cx = width / 2f
        // Sit the dot a little above centre in full-screen mode, to leave room
        // for the two lines of text beneath it.
        // Only the full-screen layout is drawn here; the pill lives in its own
        // floating window, so this view never has to shrink itself.
        val cy = height * 0.42f
        val unit = minOf(width, height) * 0.19f

        if (!MeterService.micGranted(context)) {
            title.color = paper
            title.textSize = unit * 0.30f
            canvas.drawText(Prefs.text(context, R.string.mic_denied_title), cx, height / 2f, title)
            sub.color = quiet
            sub.textSize = unit * 0.20f
            canvas.drawText(Prefs.text(context, R.string.mic_denied_sub), cx, height / 2f + unit * 0.5f, sub)
            return
        }

        if (Prefs.screenMustStayDark(context)) {
            title.color = Color.parseColor("#3A4048")
            title.textSize = unit * 0.26f
            canvas.drawText(Prefs.text(context, R.string.driving_title), cx, height / 2f, title)
            sub.color = Color.parseColor("#2E343C")
            sub.textSize = unit * 0.18f
            canvas.drawText(Prefs.text(context, R.string.driving_sub), cx, height / 2f + unit * 0.45f, sub)
            return
        }

        val state = MeterService.state
        val learning = state != null && !state.ready
        shownLevel = chase(
            shownLevel,
            if (learning) 0f else state?.level ?: 0f,
            rise = 0.35f, fall = 0.08f
        )
        shownLit = chase(
            shownLit,
            if (state?.lit == true && !MeterService.paused) 1f else 0f,
            rise = 0.30f, fall = 0.10f
        )

        val radius = unit * (0.52f + 0.30f * shownLevel)
        val colour = blend(dim, accent, shownLit)

        val outer = radius * (1.9f + 1.5f * shownLevel)
        if (haloShader == null || haloColour != accent ||
            kotlin.math.abs(outer - haloRadius) > 1f
        ) {
            haloRadius = outer
            haloColour = accent
            haloShader = RadialGradient(
                cx, cy, outer,
                intArrayOf(accent, accent, Color.TRANSPARENT),
                floatArrayOf(0f, 0.18f, 1f),
                Shader.TileMode.CLAMP
            )
        }
        if (shownLit > 0.01f) {
            halo.shader = haloShader
            halo.alpha = (150f * shownLit * (0.45f + 0.55f * shownLevel)).toInt().coerceIn(0, 255)
            canvas.drawCircle(cx, cy, outer, halo)
        }

        core.shader = null
        core.color = colour
        core.alpha = 255
        canvas.drawCircle(cx, cy, radius, core)

        val words = Prefs.text(
            context,
            when {
                MeterService.paused -> R.string.state_paused
                state == null -> R.string.state_starting
                learning -> R.string.state_learning
                shownLit > 0.5f -> R.string.state_heard
                else -> R.string.state_louder
            }
        )

        run {
            val maxRadius = unit * 0.82f

            title.color = blend(paper, accent, shownLit)
            title.textSize = unit * 0.34f
            val titleY = cy + maxRadius + title.textSize * 1.25f
            canvas.drawText(words, cx, titleY, title)

            if (allowSettings) {
                // Two round buttons, comfortably larger than the 48dp minimum.
                val d = unit * 1.15f
                val gap = unit * 0.42f
                val by = height - d - unit * 0.5f
                val leftCx = cx - (d + gap) / 2f
                val rightCx = cx + (d + gap) / 2f

                pauseRect.set(leftCx - d / 2f, by, leftCx + d / 2f, by + d)
                gearRect.set(rightCx - d / 2f, by, rightCx + d / 2f, by + d)

                core.shader = null
                core.color = Color.parseColor("#1B2027")
                canvas.drawCircle(leftCx, by + d / 2f, d / 2f, core)
                canvas.drawCircle(rightCx, by + d / 2f, d / 2f, core)

                drawTransportIcon(canvas, leftCx, by + d / 2f, d * 0.34f, !MeterService.paused)
                drawGearIcon(canvas, rightCx, by + d / 2f, d * 0.42f)
            }
        }
    }

    /** Two bars, or a triangle. Sized from the button height. */
    private fun drawTransportIcon(canvas: Canvas, cx: Float, cy: Float, size: Float, playing: Boolean) {
        icon.style = Paint.Style.FILL
        icon.color = paper
        if (playing) {
            // Pause: two bars.
            val barW = size * 0.28f
            val gap = size * 0.24f
            val h = size
            iconRect.set(cx - gap / 2f - barW, cy - h / 2f, cx - gap / 2f, cy + h / 2f)
            canvas.drawRoundRect(iconRect, barW * 0.3f, barW * 0.3f, icon)
            iconRect.set(cx + gap / 2f, cy - h / 2f, cx + gap / 2f + barW, cy + h / 2f)
            canvas.drawRoundRect(iconRect, barW * 0.3f, barW * 0.3f, icon)
        } else {
            // Play: a triangle, nudged right so it reads as centred.
            iconPath.reset()
            val h = size
            val w = size * 0.86f
            val left = cx - w * 0.38f
            iconPath.moveTo(left, cy - h / 2f)
            iconPath.lineTo(left + w, cy)
            iconPath.lineTo(left, cy + h / 2f)
            iconPath.close()
            canvas.drawPath(iconPath, icon)
        }
    }

    /** A gear: eight teeth around a ring. Drawn, so it stays crisp at any size. */
    private fun drawGearIcon(canvas: Canvas, cx: Float, cy: Float, size: Float) {
        val r = size * 0.5f
        icon.color = paper

        // Teeth.
        icon.style = Paint.Style.FILL
        val toothW = size * 0.19f
        val toothH = size * 0.26f
        for (i in 0 until 8) {
            val a = i * 45f
            canvas.save()
            canvas.rotate(a, cx, cy)
            iconRect.set(cx - toothW / 2f, cy - r - toothH * 0.42f, cx + toothW / 2f, cy - r + toothH * 0.58f)
            canvas.drawRoundRect(iconRect, toothW * 0.28f, toothW * 0.28f, icon)
            canvas.restore()
        }

        // Rim, with the hole left open by stroking rather than filling.
        icon.style = Paint.Style.STROKE
        icon.strokeWidth = size * 0.22f
        canvas.drawCircle(cx, cy, r * 0.66f, icon)
        icon.style = Paint.Style.FILL
    }

    private fun blend(from: Int, to: Int, t: Float): Int {
        val k = t.coerceIn(0f, 1f)
        return Color.rgb(
            (Color.red(from) + (Color.red(to) - Color.red(from)) * k).toInt(),
            (Color.green(from) + (Color.green(to) - Color.green(from)) * k).toInt(),
            (Color.blue(from) + (Color.blue(to) - Color.blue(from)) * k).toInt()
        )
    }
}
