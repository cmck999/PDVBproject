package com.pdvoicebuddy

import android.content.Context
import android.graphics.Color

/**
 * Everything the user can change, and the plain words used to describe it.
 *
 * Deliberately few: five sensitivity steps, four colours, two shapes. Every
 * extra option is one more thing that can be set wrong and then forgotten.
 */
object Prefs {

    private const val FILE = "buddy"
    private const val KEY_EFFORT = "effort"
    private const val KEY_COLOUR = "colour"
    private const val KEY_SHAPE = "shape"
    private const val KEY_CAR = "car"
    private const val KEY_LANG = "lang"
    private const val KEY_MIC_OFFSET = "micOffset"
    private const val KEY_UPD_CHECK = "updLastCheck"
    private const val KEY_UPD_CODE = "updCode"
    private const val KEY_UPD_NAME = "updName"
    private const val KEY_UPD_URL = "updUrl"
    private const val KEY_UPD_NOTES = "updNotes"
    private const val KEY_UPD_MIN = "updMin"
    private const val KEY_UPD_DISMISSED = "updDismissed"
    private const val KEY_FLOAT_X = "floatX"
    private const val KEY_FLOAT_Y = "floatY"

    /**
     * The five steps. Index into [EFFORTS].
     *
     * Each carries TWO numbers, because the dot needs the voice to clear both:
     *
     *   marginDb  — how far above the room. Handles noisy places.
     *   targetSpl — an absolute level in dB SPL. Handles quiet places, where
     *               clearing the room proves nothing.
     *
     * The targets run across the normal conversational band, 60-70 dB, which
     * is the level the app exists to encourage. Gentle sits just below it as a
     * starting point for someone who cannot reach 60 yet.
     *
     * Names are string resource ids, not literals, so the whole app follows the
     * device language. The numbers are of course the same in any language.
     */
    val EFFORTS = listOf(
        Effort(R.string.effort_gentle, R.string.effort_gentle_note, 7f, 57f),
        Effort(R.string.effort_easy, R.string.effort_easy_note, 10f, 60f),
        Effort(R.string.effort_normal, R.string.effort_normal_note, 13f, 63f),
        Effort(R.string.effort_firm, R.string.effort_firm_note, 16f, 66f),
        Effort(R.string.effort_strong, R.string.effort_strong_note, 19f, 69f),
    )

    val COLOURS = listOf(
        Swatch(R.string.colour_mint, Color.parseColor("#2BFFA3")),
        Swatch(R.string.colour_amber, Color.parseColor("#FFC53D")),
        Swatch(R.string.colour_sky, Color.parseColor("#57C7FF")),
        Swatch(R.string.colour_white, Color.parseColor("#F2F5F7")),
    )

    data class Effort(
        val nameRes: Int,
        val noteRes: Int,
        val marginDb: Float,
        /** Absolute target in dB SPL, at roughly an arm's length. */
        val targetSpl: Float,
    )
    data class Swatch(val nameRes: Int, val colour: Int)

    /** Follow the device. The right answer for most people. */
    const val LANG_AUTO = 0
    const val LANG_EN = 1
    const val LANG_ES = 2

    /**
     * Names shown in Settings — each in its OWN language, never translated.
     * Someone hunting for Spanish on an English tablet needs to recognise
     * "Español" on sight, whatever the app is currently showing.
     */
    val LANGUAGES = listOf(
        Triple(LANG_AUTO, "Automatic", R.string.lang_auto),
        Triple(LANG_EN, "English", 0),
        Triple(LANG_ES, "Espa\u00f1ol", 0),
    )

    const val SHAPE_FULL = 0
    const val SHAPE_PILL = 1

    /** Not in a car — the normal case. */
    const val CAR_NO = 0
    /** A passenger: the dot is fine, nobody is steering. */
    const val CAR_PASSENGER = 1
    /** Driving: screen stays dark, a buzz is the only cue. */
    const val CAR_DRIVING = 2

    private fun prefs(context: Context) =
        context.getSharedPreferences(FILE, Context.MODE_PRIVATE)

    fun effortIndex(context: Context): Int =
        prefs(context).getInt(KEY_EFFORT, 2).coerceIn(0, EFFORTS.lastIndex)

    fun setEffortIndex(context: Context, i: Int) {
        prefs(context).edit().putInt(KEY_EFFORT, i.coerceIn(0, EFFORTS.lastIndex)).apply()
        MeterService.reloadSettings(context)
    }

    fun marginDb(context: Context): Float = EFFORTS[effortIndex(context)].marginDb

    fun targetSpl(context: Context): Float = EFFORTS[effortIndex(context)].targetSpl

    /**
     * dB SPL = dBFS + this.
     *
     * A phone microphone is not a sound level meter: it has no absolute
     * reference, its gain varies by model, and the reading falls off with
     * distance. So this is an approximation, adjustable by the user against a
     * real meter, and the default is a middle-of-the-road guess for a tablet
     * at roughly an arm's length.
     *
     * Everything about the app that matters still works if this is wrong by a
     * few dB — the relative half is unaffected, and the absolute half only
     * shifts the bar slightly. It is not, and must never be presented as, a
     * measurement.
     */
    fun micOffsetDb(context: Context): Float =
        prefs(context).getFloat(KEY_MIC_OFFSET, DEFAULT_MIC_OFFSET)

    fun setMicOffsetDb(context: Context, value: Float) {
        prefs(context).edit()
            .putFloat(KEY_MIC_OFFSET, value.coerceIn(70f, 120f))
            .apply()
        MeterService.reloadSettings(context)
    }

    fun resetMicOffset(context: Context) {
        setMicOffsetDb(context, DEFAULT_MIC_OFFSET)
    }

    /** The absolute bar in dBFS, which is what VoiceCue works in. */
    fun targetDbfs(context: Context): Float =
        targetSpl(context) - micOffsetDb(context)

    /** Turns a raw dBFS reading into the approximate SPL shown on screen. */
    fun splOf(context: Context, dbfs: Float): Float = dbfs + micOffsetDb(context)

    const val DEFAULT_MIC_OFFSET = 95f

    // ---- updates ----------------------------------------------------------

    fun lastUpdateCheck(context: Context): Long =
        prefs(context).getLong(KEY_UPD_CHECK, 0L)

    fun setLastUpdateCheck(context: Context, whenMs: Long) {
        prefs(context).edit().putLong(KEY_UPD_CHECK, whenMs).apply()
    }

    /** Notes are stored newline-joined: a list of strings is not a pref type. */
    fun storeUpdate(context: Context, u: UpdateCheck.Available) {
        prefs(context).edit()
            .putInt(KEY_UPD_CODE, u.versionCode)
            .putString(KEY_UPD_NAME, u.versionName)
            .putString(KEY_UPD_URL, u.url)
            .putString(KEY_UPD_NOTES, u.notes.joinToString("\n"))
            .apply()
    }

    fun storeMinSupported(context: Context, min: Int) {
        prefs(context).edit().putInt(KEY_UPD_MIN, min).apply()
    }

    fun storedUpdate(context: Context): UpdateCheck.Available? {
        val p = prefs(context)
        val code = p.getInt(KEY_UPD_CODE, 0)
        val url = p.getString(KEY_UPD_URL, null)
        if (code <= 0 || url.isNullOrBlank()) return null
        return UpdateCheck.Available(
            versionCode = code,
            versionName = p.getString(KEY_UPD_NAME, code.toString()) ?: code.toString(),
            url = url,
            notes = (p.getString(KEY_UPD_NOTES, "") ?: "")
                .split("\n").filter { it.isNotBlank() },
            critical = UpdateCheck.isCritical(context, p.getInt(KEY_UPD_MIN, 0)),
        )
    }

    /** The newest version the user has waved away. Ignored when critical. */
    fun dismissedUpdate(context: Context): Int =
        prefs(context).getInt(KEY_UPD_DISMISSED, 0)

    fun dismissUpdate(context: Context, versionCode: Int) {
        prefs(context).edit().putInt(KEY_UPD_DISMISSED, versionCode).apply()
    }

    fun colourIndex(context: Context): Int =
        prefs(context).getInt(KEY_COLOUR, 0).coerceIn(0, COLOURS.lastIndex)

    fun setColourIndex(context: Context, i: Int) {
        prefs(context).edit().putInt(KEY_COLOUR, i.coerceIn(0, COLOURS.lastIndex)).apply()
    }

    fun colour(context: Context): Int = COLOURS[colourIndex(context)].colour

    fun language(context: Context): Int =
        prefs(context).getInt(KEY_LANG, LANG_AUTO)

    fun setLanguage(context: Context, mode: Int) {
        prefs(context).edit().putInt(KEY_LANG, mode).apply()
    }

    /**
     * The locale to draw in, or null to follow the device.
     *
     * A device set up in English by a family member must not decide what
     * language the person using it reads, so this is overridable.
     */
    fun forcedLocale(context: Context): java.util.Locale? = when (language(context)) {
        LANG_EN -> java.util.Locale.ENGLISH
        LANG_ES -> java.util.Locale("es")
        else -> null
    }

    private var cachedLang = -1
    private var cachedContext: Context? = null

    /**
     * getString() in the chosen language. Cached, because the views call this
     * every frame and building a Configuration each time would be wasteful.
     */
    fun text(context: Context, resId: Int): String {
        val lang = language(context)
        if (lang != cachedLang || cachedContext == null) {
            cachedLang = lang
            cachedContext = localised(context.applicationContext ?: context)
        }
        return (cachedContext ?: context).getString(resId)
    }

    /** Wraps a context so getString() answers in the chosen language. */
    fun localised(context: Context): Context {
        val locale = forcedLocale(context) ?: return context
        val config = android.content.res.Configuration(context.resources.configuration)
        config.setLocale(locale)
        return context.createConfigurationContext(config)
    }

    fun shape(context: Context): Int =
        prefs(context).getInt(KEY_SHAPE, SHAPE_FULL)

    fun setShape(context: Context, shape: Int) {
        prefs(context).edit().putInt(KEY_SHAPE, shape).apply()
    }

    /**
     * Android cannot tell a driver from a passenger, so this is never guessed.
     * It resets to CAR_NO every time the app starts, which is the safe default:
     * a stale "passenger" setting must never survive into the next journey.
     */
    fun car(context: Context): Int = prefs(context).getInt(KEY_CAR, CAR_NO)

    fun setCar(context: Context, mode: Int) {
        prefs(context).edit().putInt(KEY_CAR, mode).apply()
    }

    fun clearCarOnLaunch(context: Context) {
        prefs(context).edit().putInt(KEY_CAR, CAR_NO).apply()
    }

    /**
     * The pill IS the floating one — choosing it is choosing to float. Kept as a
     * derived value rather than a second setting, so the two can never disagree
     * and leave a pill on screen and another one over it.
     */
    fun floating(context: Context): Boolean = shape(context) == SHAPE_PILL

    fun floatX(context: Context, fallback: Int): Int =
        prefs(context).getInt(KEY_FLOAT_X, fallback)

    fun floatY(context: Context, fallback: Int): Int =
        prefs(context).getInt(KEY_FLOAT_Y, fallback)

    fun setFloatPosition(context: Context, x: Int, y: Int) {
        prefs(context).edit().putInt(KEY_FLOAT_X, x).putInt(KEY_FLOAT_Y, y).apply()
    }

    /** True when nothing may be drawn on screen. */
    fun screenMustStayDark(context: Context): Boolean = car(context) == CAR_DRIVING
}
