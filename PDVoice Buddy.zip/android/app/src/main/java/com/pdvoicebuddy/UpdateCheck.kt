package com.pdvoicebuddy

import android.content.Context
import android.content.Intent
import android.net.Uri
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

/**
 * Checking GitHub Releases for a newer build.
 *
 * The app reads one small JSON file from the repository — not the GitHub API,
 * which is rate-limited and needs no authentication only by luck. A plain file
 * on the default branch is stable, cacheable and easy for a non-programmer to
 * edit by hand in the browser.
 *
 * Deliberate limits:
 *
 *   - Nothing is ever installed silently. Android cannot do that outside the
 *     Play Store, and pretending otherwise would be a lie in the UI.
 *   - A critical update is a banner that cannot be dismissed. It is NOT a
 *     lock screen. Disabling the voice cue to force an upgrade would punish
 *     the person for something only the developer can fix.
 *   - Failure is silent. No network, no server, bad JSON — the app carries on
 *     and tries again tomorrow. An update check is not worth an error message.
 */
object UpdateCheck {

    /**
     * The manifest, on the default branch of the project repository.
     *
     * This is the raw.githubusercontent.com address, NOT the github.com page
     * address — the page would return HTML. If the repository is ever renamed
     * or its default branch stops being "main", this line has to change and
     * nothing else does.
     */
    const val MANIFEST_URL =
        "https://raw.githubusercontent.com/cmck999/PDVBproject/main/latest.json"

    private const val DAY_MS = 24 * 60 * 60 * 1000L
    private const val TIMEOUT_MS = 8000

    data class Available(
        val versionCode: Int,
        val versionName: String,
        val url: String,
        val notes: List<String>,
        /** True when this build is older than the oldest one still supported. */
        val critical: Boolean,
    )

    /** The current build, for display and comparison. */
    fun installedVersionCode(context: Context): Int =
        try {
            @Suppress("DEPRECATION")
            context.packageManager.getPackageInfo(context.packageName, 0).versionCode
        } catch (e: Exception) {
            0
        }

    fun installedVersionName(context: Context): String =
        try {
            context.packageManager.getPackageInfo(context.packageName, 0).versionName ?: "?"
        } catch (e: Exception) {
            "?"
        }

    /**
     * The update worth telling the user about, or null.
     *
     * Reads only what the last check stored, so it is cheap enough to call
     * from onResume. Respects a dismissal unless the update is critical.
     */
    fun pending(context: Context): Available? {
        val stored = Prefs.storedUpdate(context) ?: return null
        if (stored.versionCode <= installedVersionCode(context)) return null
        if (!stored.critical && Prefs.dismissedUpdate(context) >= stored.versionCode) return null
        return stored
    }

    /**
     * Fetches the manifest on a background thread if a day has passed.
     *
     * @param force ignores the once-a-day rule, for the Check now button.
     * @param done called on the calling thread's looper via [onDone], or not
     *             at all if the check was skipped.
     */
    fun maybeCheck(context: Context, force: Boolean = false, onDone: (() -> Unit)? = null) {
        val now = System.currentTimeMillis()
        if (!force && now - Prefs.lastUpdateCheck(context) < DAY_MS) return
        // Recorded before the attempt, so a server that is down cannot cause a
        // check on every single launch.
        Prefs.setLastUpdateCheck(context, now)

        Thread {
            val fetched = fetchRaw()
            if (fetched != null) {
                Prefs.storeMinSupported(context, fetched.second)
                Prefs.storeUpdate(context, fetched.first)
            }
            onDone?.let { cb ->
                android.os.Handler(android.os.Looper.getMainLooper()).post { cb() }
            }
        }.apply { isDaemon = true }.start()
    }

    /** The parsed manifest, paired with its minSupportedVersionCode. */
    private fun fetchRaw(): Pair<Available, Int>? = try {
        val conn = (URL(MANIFEST_URL).openConnection() as HttpURLConnection).apply {
            connectTimeout = TIMEOUT_MS
            readTimeout = TIMEOUT_MS
            requestMethod = "GET"
            setRequestProperty("Accept", "application/json")
        }
        val body = conn.inputStream.bufferedReader().use { it.readText() }
        conn.disconnect()

        val android = JSONObject(body).getJSONObject("android")
        val code = android.getInt("versionCode")
        val notes = mutableListOf<String>()
        android.optJSONArray("notes")?.let { arr ->
            for (i in 0 until arr.length()) notes += arr.getString(i)
        }
        Available(
            versionCode = code,
            versionName = android.optString("versionName", code.toString()),
            url = android.getString("url"),
            notes = notes,
            // Filled in by storedUpdate, which can see the installed version.
            critical = false,
        ) to android.optInt("minSupportedVersionCode", 0)
    } catch (e: Exception) {
        null   // Silent by design. Tries again tomorrow.
    }

    /**
     * Whether THIS build falls below the manifest's supported floor. Kept
     * separate from [fetch] because it needs the installed version, which the
     * background thread has no business reading.
     */
    fun isCritical(context: Context, minSupported: Int): Boolean =
        minSupported > 0 && installedVersionCode(context) < minSupported

    /** Hands the APK to the browser, which handles the download and install. */
    fun openDownload(context: Context, url: String) {
        try {
            context.startActivity(
                Intent(Intent.ACTION_VIEW, Uri.parse(url))
                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            )
        } catch (e: Exception) {
            // No browser, somehow. Nothing useful to say.
        }
    }
}
