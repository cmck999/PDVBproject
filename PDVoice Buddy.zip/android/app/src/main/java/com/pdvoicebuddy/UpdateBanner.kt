package com.pdvoicebuddy

import android.app.Activity
import android.content.Context
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.view.Gravity
import android.view.View
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView

/**
 * The strip that appears above the dot when a new build exists.
 *
 * Sits at the TOP so it never covers the dot, which is the one thing on screen
 * that matters. Tall targets, plain words, and no jargon: a tester should not
 * have to know what an APK is.
 *
 * A critical update loses its "Later" button but keeps the dot running. The
 * banner is an insistence, not a lock.
 */
object UpdateBanner {

    fun build(activity: Activity, update: UpdateCheck.Available, onDismiss: () -> Unit): View {
        val accent = Prefs.colour(activity)
        val urgent = update.critical
        val edge = if (urgent) Color.parseColor("#FF8A6B") else accent

        val card = LinearLayout(activity).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(activity, 18), dp(activity, 16), dp(activity, 18), dp(activity, 16))
            background = GradientDrawable().apply {
                cornerRadius = dp(activity, 14).toFloat()
                setColor(Color.parseColor("#161B22"))
                setStroke(dp(activity, 2), edge)
            }
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            ).apply {
                leftMargin = dp(activity, 16)
                rightMargin = dp(activity, 16)
                topMargin = dp(activity, 16)
            }
        }

        card.addView(TextView(activity).apply {
            text = activity.getString(
                if (urgent) R.string.upd_title_critical else R.string.upd_title,
                update.versionName
            )
            setTextColor(if (urgent) edge else Color.parseColor("#E6E8EC"))
            textSize = 17f
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
        })

        if (update.notes.isNotEmpty()) {
            card.addView(TextView(activity).apply {
                // Bulleted by hand: a list view here would be four classes of
                // machinery for three lines of text.
                text = update.notes.joinToString("\n") { "•  $it" }
                setTextColor(Color.parseColor("#9BA1A9"))
                textSize = 14f
                setPadding(0, dp(activity, 8), 0, 0)
            })
        }

        card.addView(TextView(activity).apply {
            text = activity.getString(R.string.upd_how)
            setTextColor(Color.parseColor("#7F858D"))
            textSize = 12f
            setPadding(0, dp(activity, 10), 0, dp(activity, 12))
        })

        val row = LinearLayout(activity).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }

        row.addView(Button(activity).apply {
            text = activity.getString(R.string.upd_get)
            textSize = 16f
            minimumHeight = dp(activity, 56)
            setTextColor(Color.parseColor("#0B0E13"))
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
            background = GradientDrawable().apply {
                cornerRadius = dp(activity, 10).toFloat()
                setColor(edge)
            }
            layoutParams = LinearLayout.LayoutParams(
                0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f
            ).apply { rightMargin = dp(activity, 10) }
            setOnClickListener { UpdateCheck.openDownload(activity, update.url) }
        })

        if (!urgent) {
            row.addView(Button(activity).apply {
                text = activity.getString(R.string.upd_later)
                textSize = 15f
                minimumHeight = dp(activity, 56)
                setTextColor(Color.parseColor("#8D929A"))
                background = GradientDrawable().apply {
                    cornerRadius = dp(activity, 10).toFloat()
                    setColor(Color.parseColor("#0B0E13"))
                    setStroke(dp(activity, 1), Color.parseColor("#3A4048"))
                }
                setOnClickListener {
                    Prefs.dismissUpdate(activity, update.versionCode)
                    onDismiss()
                }
            })
        }

        card.addView(row)
        return card
    }

    private fun dp(context: Context, value: Int): Int =
        (value * context.resources.displayMetrics.density).toInt()
}
