package com.pdvoicebuddy

import android.app.Service
import android.content.Context
import android.content.Intent
import android.graphics.PixelFormat
import android.os.IBinder
import android.provider.Settings
import android.view.Gravity
import android.view.WindowManager

/**
 * Puts the pill on top of every other app.
 *
 * This is the one feature that needs a permission the user has to grant in a
 * system settings screen rather than a dialog, which is why it is optional and
 * off by default. Everything else in the app works without it.
 */
class OverlayService : Service() {

    companion object {
        @Volatile var showing = false
            private set

        fun granted(context: Context): Boolean = Settings.canDrawOverlays(context)

        fun start(context: Context) {
            if (showing || !granted(context)) return
            context.startService(Intent(context, OverlayService::class.java))
        }

        fun stop(context: Context) {
            context.stopService(Intent(context, OverlayService::class.java))
        }

        /** Reflects the saved preference, if we are allowed to. */
        fun sync(context: Context) {
            if (Prefs.floating(context) && granted(context) && !Prefs.screenMustStayDark(context)) {
                start(context)
            } else {
                stop(context)
            }
        }
    }

    private var wm: WindowManager? = null
    private var view: PillView? = null
    private var params: WindowManager.LayoutParams? = null

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        if (!granted(this)) { stopSelf(); return }

        val manager = getSystemService(WindowManager::class.java)
        val density = resources.displayMetrics.density
        val lp = WindowManager.LayoutParams(
            (336 * density).toInt(),
            (78 * density).toInt(),
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = Prefs.floatX(this@OverlayService, fallback = (16 * density).toInt())
            y = Prefs.floatY(this@OverlayService, fallback = (120 * density).toInt())
        }

        val pill = PillView(
            this,
            onDrag = { dx, dy ->
                lp.x += dx.toInt()
                lp.y += dy.toInt()
                try { manager.updateViewLayout(view, lp) } catch (_: Exception) {}
            },
            onDragEnd = { Prefs.setFloatPosition(this, lp.x, lp.y) }
        )

        try {
            manager.addView(pill, lp)
        } catch (e: Exception) {
            stopSelf()
            return
        }

        wm = manager
        view = pill
        params = lp
        showing = true
        MeterService.start(this)
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int = START_STICKY

    override fun onDestroy() {
        showing = false
        try { view?.let { wm?.removeView(it) } } catch (_: Exception) {}
        view = null
        wm = null
        params = null
        super.onDestroy()
    }
}
