package com.pdvoicebuddy

import kotlin.math.log10
import kotlin.math.max
import kotlin.math.sqrt

/**
 * The whole measurement, and the only file worth arguing about.
 *
 * Deliberately contains NO Android imports. It takes numbers in and gives a
 * verdict out, which is what makes it testable on a laptop and reusable as a
 * library later.
 *
 * TWO thresholds, and the dot lights only when the voice clears BOTH:
 *
 *   1. Above the room, by [marginDb]. Being audible is relative — the same
 *      voice that carries in a kitchen is lost in a restaurant, and no fixed
 *      number can express that.
 *
 *   2. Above an absolute level, [targetDbfs]. Because the point is not merely
 *      to be audible: it is to practise projecting at a normal conversational
 *      volume, roughly 60-70 dB. In a silent room the relative test alone
 *      would light up for a whisper, which teaches exactly the wrong habit.
 *
 * Equivalently: the bar is whichever of the two is higher. The room decides in
 * a restaurant; the absolute target decides in a quiet living room.
 *
 * The absolute half needs a calibration constant, which lives in Prefs rather
 * than here — this class only ever sees dBFS.
 */
class VoiceCue(
    /** How far above the room noise counts as carrying. */
    private val marginDb: Float = 12f,
    /**
     * The absolute bar, in dBFS, or null for no absolute bar at all.
     *
     * Null is the old purely-relative behaviour. It is kept because it is the
     * honest way to test the relative half in isolation, not because any real
     * configuration uses it.
     */
    private val targetDbfs: Float? = null,
    /** How long the verdict stays lit after the last qualifying sample. */
    private val holdMs: Long = 700L,
    /** How fast the room estimate follows sound going quieter. */
    private val fallRate: Float = 0.05f,
    /** How fast it follows sound getting louder. Slow, so speech can't drag it up. */
    private val riseRate: Float = 0.006f,
    /** Above the room by this much counts as speaking at all. */
    private val speechMarginDb: Float = 6f,
    /**
     * At startup the room estimate knows nothing, so for this long it tracks
     * quickly in both directions. Without it the app spends its first minute
     * mistaking ordinary room noise for a raised voice.
     */
    private val warmUpMs: Long = 1500L,
) {

    data class State(
        /** Drives the dot. */
        val lit: Boolean,
        /** How far the voice is above the room, in dB. */
        val aboveDb: Float,
        /** 0..1, for size and glow. */
        val level: Float,
        /** True while she is talking at all — what the daily % counts. */
        val isSpeech: Boolean,
        /** The current room estimate, for display and debugging. */
        val floorDb: Float,
        /** The bar actually in force, in dBFS — the higher of the two. */
        val thresholdDb: Float,
        /** True when the absolute target is the binding one, not the room. */
        val absoluteBinding: Boolean,
        /** The current level in dBFS, for the calibration screen. */
        val db: Float,
        /** False until the room estimate has settled. */
        val ready: Boolean,
    )

    var floorDb: Float = 0f
        private set

    private var startedAtMs = Long.MIN_VALUE
    private var lastAboveMs = Long.MIN_VALUE / 4

    fun reset() {
        startedAtMs = Long.MIN_VALUE
        floorDb = 0f
        lastAboveMs = Long.MIN_VALUE / 4
    }

    /** One frame of mono PCM in -1..1. */
    fun push(samples: FloatArray, nowMs: Long): State = pushDb(dbOf(samples), nowMs)

    /** Same thing, given a level directly. Used by the tests. */
    fun pushDb(db: Float, nowMs: Long): State {
        if (startedAtMs == Long.MIN_VALUE) {
            startedAtMs = nowMs
            floorDb = db
        }

        val warming = nowMs - startedAtMs < warmUpMs
        floorDb = when {
            // Learning the room: follow it quickly, up or down.
            warming -> lerp(floorDb, db, 0.25f)
            // Settled: drops fast, rises slowly, so a sentence can't drag it up
            // but a lorry going past still raises the bar.
            db < floorDb -> lerp(floorDb, db, fallRate)
            else -> lerp(floorDb, db, riseRate)
        }

        val relative = floorDb + marginDb
        val absolute = targetDbfs ?: Float.NEGATIVE_INFINITY
        val threshold = max(relative, absolute)

        if (!warming && db >= threshold) lastAboveMs = nowMs
        val lit = !warming && nowMs - lastAboveMs < holdMs

        // The dot grows as she approaches the bar, so effort is visible before
        // it is rewarded. Span scales with the margin to keep the old feel.
        val span = marginDb + 8f
        val level = ((db - threshold + span) / (span + 6f)).coerceIn(0f, 1f)

        return State(
            lit = lit,
            aboveDb = db - floorDb,
            level = level,
            isSpeech = !warming && db - floorDb > speechMarginDb,
            floorDb = floorDb,
            thresholdDb = threshold,
            absoluteBinding = absolute > relative,
            db = db,
            ready = !warming,
        )
    }

    private fun lerp(from: Float, to: Float, t: Float) = from + (to - from) * t

    companion object {
        /** dBFS. Negative. Meaningless on its own without a calibration offset. */
        fun dbOf(samples: FloatArray): Float {
            if (samples.isEmpty()) return -120f
            var sum = 0.0
            for (s in samples) sum += (s * s).toDouble()
            val rms = sqrt(sum / samples.size).toFloat()
            return 20f * log10(if (rms < 1e-7f) 1e-7f else rms)
        }
    }
}
