package com.pdvoicebuddy

import android.service.dreams.DreamService

/**
 * The screensaver. Android starts this by itself when the tablet is docked or
 * charging, which means the whole interaction becomes "put it on the stand".
 *
 * Enable once: Settings -> Display -> Screen saver -> PDVoice Buddy.
 */
class BuddyDream : DreamService() {

    override fun onAttachedToWindow() {
        super.onAttachedToWindow()
        isFullscreen = true
        isScreenBright = true
        isInteractive = false          // any touch exits, as a screensaver should
        setContentView(RingView(this, allowSettings = false))
    }

    override fun onDreamingStarted() {
        super.onDreamingStarted()
        MeterService.start(this)
    }
}
