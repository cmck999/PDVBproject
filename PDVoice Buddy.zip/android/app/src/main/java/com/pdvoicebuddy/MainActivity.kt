package com.pdvoicebuddy

import android.Manifest
import android.app.Activity
import android.os.Build
import android.os.Bundle
import android.view.Gravity
import android.view.WindowManager
import android.widget.FrameLayout
import android.widget.LinearLayout

class MainActivity : Activity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Prefs.clearCarOnLaunch(this)

        // The ring fills the screen; the banner floats above it when there is
        // something to say. A FrameLayout rather than a vertical stack so the
        // dot never shrinks or shifts to make room.
        frame = FrameLayout(this).apply { addView(RingView(this@MainActivity)) }
        bannerHost = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            layoutParams = FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT,
                FrameLayout.LayoutParams.WRAP_CONTENT
            ).apply { gravity = Gravity.TOP }
        }
        frame.addView(bannerHost)
        setContentView(frame)

        // The ring is useless if the screen sleeps mid-conversation.
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)

        val wanted = mutableListOf<String>()
        if (!MeterService.micGranted(this)) wanted += Manifest.permission.RECORD_AUDIO
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            wanted += Manifest.permission.POST_NOTIFICATIONS
        }
        if (wanted.isNotEmpty()) requestPermissions(wanted.toTypedArray(), 1)

        // Once a day, quietly, in the background. Refreshes the banner if the
        // answer arrives while the screen is still open.
        UpdateCheck.maybeCheck(this) { showBannerIfAny() }
    }

    private lateinit var frame: FrameLayout
    private lateinit var bannerHost: LinearLayout

    private fun showBannerIfAny() {
        bannerHost.removeAllViews()
        val update = UpdateCheck.pending(this) ?: return
        bannerHost.addView(
            UpdateBanner.build(this, update) { showBannerIfAny() }
        )
    }

    override fun onRequestPermissionsResult(
        requestCode: Int,
        permissions: Array<out String>,
        grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        MeterService.start(this)
    }

    override fun onResume() {
        super.onResume()
        MeterService.start(this)
        OverlayService.sync(this)

        // In pill mode the floating window is the app. Once it is up there is
        // nothing for this screen to show, so it steps aside rather than
        // explaining itself. Settings live on the pill's own gear.
        showBannerIfAny()

        if (Prefs.shape(this) == Prefs.SHAPE_PILL &&
            OverlayService.showing &&
            MeterService.micGranted(this) &&
            // …unless there is an update to announce. The pill has no room for
            // a banner, so this screen stays put until it has been dealt with.
            UpdateCheck.pending(this) == null
        ) {
            finish()
        }
    }
}
