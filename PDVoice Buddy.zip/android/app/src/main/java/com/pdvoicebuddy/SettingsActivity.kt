package com.pdvoicebuddy

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.provider.Settings
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.View
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView

/**
 * Settings, built for hands that shake.
 *
 * Every control is a full-width row at least 64dp tall — no sliders, no small
 * targets, nothing that needs a precise drag. Options are named in plain words
 * rather than decibels, because the number means nothing to the person using it.
 */
class SettingsActivity : Activity() {

    private val backdrop = Color.parseColor("#0B0E13")
    private val card = Color.parseColor("#161B22")
    private val paper = Color.parseColor("#E6E8EC")
    private val quiet = Color.parseColor("#8D929A")

    private lateinit var root: LinearLayout

    override fun attachBaseContext(newBase: Context) {
        super.attachBaseContext(Prefs.localised(newBase))
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val scroll = ScrollView(this).apply { setBackgroundColor(backdrop) }
        root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(24), dp(28), dp(24), dp(40))
        }
        scroll.addView(root)
        setContentView(scroll)

        build()
    }

    private var pendingPill = false

    override fun onResume() {
        super.onResume()
        if (pendingPill && OverlayService.granted(this)) {
            pendingPill = false
            Prefs.setShape(this, Prefs.SHAPE_PILL)
        }
        OverlayService.sync(this)
        build()
        ticker.removeCallbacks(tick)
        ticker.post(tick)
    }

    private fun build() {
        root.removeAllViews()

        root.addView(heading(getString(R.string.settings_title)))

        root.addView(label(getString(R.string.car_label)))
        root.addView(note(getString(R.string.car_note)))
        root.addView(
            choice(
                title = getString(R.string.car_no),
                subtitle = null,
                selected = Prefs.car(this) == Prefs.CAR_NO,
                accent = Prefs.colour(this)
            ) { Prefs.setCar(this, Prefs.CAR_NO); OverlayService.sync(this); build() }
        )
        root.addView(
            choice(
                title = getString(R.string.car_passenger),
                subtitle = getString(R.string.car_passenger_sub),
                selected = Prefs.car(this) == Prefs.CAR_PASSENGER,
                accent = Prefs.colour(this)
            ) { Prefs.setCar(this, Prefs.CAR_PASSENGER); OverlayService.sync(this); build() }
        )
        root.addView(
            choice(
                title = getString(R.string.car_driving),
                subtitle = getString(R.string.car_driving_sub),
                selected = Prefs.car(this) == Prefs.CAR_DRIVING,
                accent = Prefs.colour(this)
            ) { Prefs.setCar(this, Prefs.CAR_DRIVING); OverlayService.sync(this); build() }
        )

        root.addView(label(getString(R.string.effort_label)))
        root.addView(note(getString(R.string.effort_note)))
        root.addView(note(getString(R.string.effort_target_note)))
        Prefs.EFFORTS.forEachIndexed { i, effort ->
            root.addView(
                choice(
                    title = getString(effort.nameRes),
                    subtitle = getString(effort.noteRes),
                    selected = i == Prefs.effortIndex(this),
                    accent = Prefs.colour(this)
                ) {
                    Prefs.setEffortIndex(this, i)
                    build()
                }
            )
        }

        root.addView(label(getString(R.string.colour_label)))
        Prefs.COLOURS.forEachIndexed { i, swatch ->
            root.addView(
                choice(
                    title = getString(swatch.nameRes),
                    subtitle = null,
                    selected = i == Prefs.colourIndex(this),
                    accent = swatch.colour,
                    dotColour = swatch.colour
                ) {
                    Prefs.setColourIndex(this, i)
                    build()
                }
            )
        }

        root.addView(label(getString(R.string.size_label)))
        root.addView(
            choice(
                title = getString(R.string.size_full),
                subtitle = getString(R.string.size_full_sub),
                selected = Prefs.shape(this) == Prefs.SHAPE_FULL,
                accent = Prefs.colour(this)
            ) {
                Prefs.setShape(this, Prefs.SHAPE_FULL)
                OverlayService.sync(this)
                build()
            }
        )
        val canFloat = OverlayService.granted(this)
        root.addView(
            choice(
                title = getString(R.string.size_pill),
                subtitle = if (canFloat)
                    getString(R.string.size_pill_sub)
                else
                    getString(R.string.size_pill_sub_blocked),
                selected = Prefs.shape(this) == Prefs.SHAPE_PILL && canFloat,
                accent = Prefs.colour(this)
            ) {
                if (!canFloat) {
                    // Android will not grant this in a dialog; it insists on its
                    // own settings screen. onResume picks up the result.
                    pendingPill = true
                    startActivity(
                        Intent(
                            Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                            Uri.parse("package:$packageName")
                        )
                    )
                } else {
                    Prefs.setShape(this, Prefs.SHAPE_PILL)
                    OverlayService.sync(this)
                    build()
                }
            }
        )

        root.addView(label(getString(R.string.upd_label)))
        root.addView(note(getString(R.string.upd_installed,
            UpdateCheck.installedVersionName(this))))
        root.addView(updateRow())

        root.addView(label(getString(R.string.calib_label)))
        root.addView(note(getString(R.string.calib_note)))
        root.addView(calibrationRow())

        root.addView(label(getString(R.string.lang_label)))
        Prefs.LANGUAGES.forEach { (mode, ownName, noteRes) ->
            root.addView(
                choice(
                    // Each language is named in itself, never translated —
                    // "Español" has to be recognisable on an English tablet.
                    title = if (noteRes != 0) getString(noteRes) else ownName,
                    subtitle = if (mode == Prefs.LANG_AUTO)
                        getString(R.string.lang_auto_note) else null,
                    selected = Prefs.language(this) == mode,
                    accent = Prefs.colour(this)
                ) {
                    if (Prefs.language(this) != mode) {
                        Prefs.setLanguage(this, mode)
                        OverlayService.sync(this)
                        // Rebuilds the activity so attachBaseContext picks up
                        // the new locale; the screen redraws in it immediately.
                        recreate()
                    }
                }
            )
        }

        root.addView(space(dp(28)))
        root.addView(bigButton(getString(R.string.settings_done), Prefs.colour(this)) { finish() })
    }

    private var updateStatus: TextView? = null

    /**
     * A manual check, for when a tester has been told an update exists and
     * does not want to wait for the daily one.
     */
    private fun updateRow(): View {
        val accent = Prefs.colour(this)
        val pending = UpdateCheck.pending(this)

        val outer = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(18), dp(14), dp(18), dp(14))
            background = GradientDrawable().apply {
                cornerRadius = dp(10).toFloat()
                setColor(card)
                if (pending != null) setStroke(dp(2), accent)
            }
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            ).apply { bottomMargin = dp(10) }
        }

        val status = TextView(this).apply {
            text = if (pending != null) {
                getString(R.string.upd_title, pending.versionName)
            } else ""
            setTextColor(if (pending != null) accent else quiet)
            textSize = 15f
            visibility = if (pending != null) View.VISIBLE else View.GONE
            setPadding(0, 0, 0, dp(10))
        }
        updateStatus = status
        outer.addView(status)

        outer.addView(Button(this).apply {
            text = if (pending != null) {
                getString(R.string.upd_get)
            } else {
                getString(R.string.upd_check)
            }
            textSize = 16f
            minimumHeight = dp(56)
            setTextColor(if (pending != null) backdrop else paper)
            background = GradientDrawable().apply {
                cornerRadius = dp(8).toFloat()
                if (pending != null) setColor(accent) else {
                    setColor(backdrop)
                    setStroke(dp(1), quiet)
                }
            }
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            )
            setOnClickListener {
                if (pending != null) {
                    UpdateCheck.openDownload(this@SettingsActivity, pending.url)
                } else {
                    status.visibility = View.VISIBLE
                    status.text = getString(R.string.upd_checking)
                    UpdateCheck.maybeCheck(this@SettingsActivity, force = true) {
                        val found = UpdateCheck.pending(this@SettingsActivity)
                        if (found != null) build() else {
                            status.text = getString(R.string.upd_none)
                        }
                    }
                }
            }
        })

        return outer
    }

    private var nowLabel: TextView? = null
    private val ticker = Handler(Looper.getMainLooper())
    private val tick = object : Runnable {
        override fun run() {
            refreshNow()
            ticker.postDelayed(this, 200)
        }
    }

    /**
     * Shows what the app currently thinks the room is, in approximate dB, with
     * two nudge buttons. Deliberately not a slider: this is compared against a
     * separate meter app, one dB at a time.
     */
    private fun calibrationRow(): View {
        val accent = Prefs.colour(this)

        val outer = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(18), dp(14), dp(18), dp(14))
            background = GradientDrawable().apply {
                cornerRadius = dp(10).toFloat()
                setColor(card)
            }
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            ).apply { bottomMargin = dp(10) }
        }

        val readout = TextView(this).apply {
            setTextColor(paper)
            textSize = 20f
            typeface = Typeface.MONOSPACE
        }
        nowLabel = readout
        outer.addView(readout)

        outer.addView(TextView(this).apply {
            text = getString(
                R.string.calib_target,
                Prefs.targetSpl(this@SettingsActivity).toInt()
            )
            setTextColor(quiet)
            textSize = 13f
            setPadding(0, dp(3), 0, dp(12))
        })

        val buttons = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        fun nudge(text: String, by: Float) = Button(this).apply {
            this.text = text
            textSize = 20f
            minimumHeight = dp(56)
            minimumWidth = dp(76)
            setTextColor(accent)
            background = GradientDrawable().apply {
                cornerRadius = dp(8).toFloat()
                setColor(backdrop)
                setStroke(dp(1), quiet)
            }
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.WRAP_CONTENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            ).apply { rightMargin = dp(10) }
            setOnClickListener {
                Prefs.setMicOffsetDb(
                    this@SettingsActivity,
                    Prefs.micOffsetDb(this@SettingsActivity) + by
                )
                refreshNow()
            }
        }
        buttons.addView(nudge(getString(R.string.calib_down), -1f))
        buttons.addView(nudge(getString(R.string.calib_up), 1f))
        buttons.addView(Button(this).apply {
            text = getString(R.string.calib_reset)
            textSize = 15f
            minimumHeight = dp(56)
            setTextColor(quiet)
            background = GradientDrawable().apply {
                cornerRadius = dp(8).toFloat()
                setColor(backdrop)
                setStroke(dp(1), quiet)
            }
            setOnClickListener {
                Prefs.resetMicOffset(this@SettingsActivity)
                refreshNow()
            }
        })
        outer.addView(buttons)

        refreshNow()
        return outer
    }

    private fun refreshNow() {
        val view = nowLabel ?: return
        val state = MeterService.state
        // Below this the reading is noise, and showing a number implies a
        // precision the microphone does not have.
        view.text = if (state == null || state.db < -70f) {
            getString(R.string.calib_quiet)
        } else {
            getString(R.string.calib_now, Prefs.splOf(this, state.db).toInt())
        }
    }

    override fun onPause() {
        super.onPause()
        ticker.removeCallbacks(tick)
    }

    // ---- pieces -------------------------------------------------------------

    private fun heading(text: String) = TextView(this).apply {
        this.text = text
        setTextColor(paper)
        textSize = 30f
        typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
        setPadding(0, 0, 0, dp(8))
    }

    private fun label(text: String) = TextView(this).apply {
        this.text = text.uppercase()
        setTextColor(quiet)
        textSize = 12f
        typeface = Typeface.MONOSPACE
        letterSpacing = 0.14f
        setPadding(0, dp(28), 0, dp(10))
    }

    private fun note(text: String) = TextView(this).apply {
        this.text = text
        setTextColor(quiet)
        textSize = 14f
        setPadding(0, 0, 0, dp(12))
    }

    private fun space(height: Int) = View(this).apply {
        layoutParams = LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT, height
        )
    }

    private fun choice(
        title: String,
        subtitle: String?,
        selected: Boolean,
        accent: Int,
        dotColour: Int? = null,
        onPick: () -> Unit
    ): View {
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            minimumHeight = dp(68)
            setPadding(dp(18), dp(14), dp(18), dp(14))
            background = GradientDrawable().apply {
                cornerRadius = dp(10).toFloat()
                setColor(card)
                if (selected) setStroke(dp(2), accent)
            }
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            ).apply { bottomMargin = dp(10) }
            isClickable = true
            setOnClickListener { onPick() }
        }

        if (dotColour != null) {
            row.addView(View(this).apply {
                layoutParams = LinearLayout.LayoutParams(dp(28), dp(28)).apply {
                    rightMargin = dp(16)
                }
                background = GradientDrawable().apply {
                    shape = GradientDrawable.OVAL
                    setColor(dotColour)
                }
            })
        }

        val words = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
        }
        words.addView(TextView(this).apply {
            text = title
            setTextColor(if (selected) accent else paper)
            textSize = 18f
            if (selected) typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
        })
        if (subtitle != null) {
            words.addView(TextView(this).apply {
                text = subtitle
                setTextColor(quiet)
                textSize = 13f
                setPadding(0, dp(3), 0, 0)
            })
        }
        row.addView(words)

        if (selected) {
            row.addView(TextView(this).apply {
                text = "✓"
                setTextColor(accent)
                textSize = 22f
            })
        }
        return row
    }

    private fun bigButton(text: String, accent: Int, onClick: () -> Unit) =
        Button(this).apply {
            this.text = text
            setTextColor(Color.parseColor("#0B0E13"))
            textSize = 18f
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
            isAllCaps = false
            background = GradientDrawable().apply {
                cornerRadius = dp(10).toFloat()
                setColor(accent)
            }
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, dp(64)
            )
            setOnClickListener { onClick() }
        }

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()
}
