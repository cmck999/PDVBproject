package com.pdvoicebuddy

import android.Manifest
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.content.pm.ServiceInfo
import android.media.AudioFormat
import android.media.AudioRecord
import android.media.MediaRecorder
import android.os.Build
import android.os.IBinder
import android.os.VibrationEffect
import android.os.Vibrator
import android.os.VibratorManager
import kotlin.concurrent.thread

/**
 * Holds the microphone and publishes the current verdict.
 *
 * Android will not allow continuous microphone access without a visible
 * notification, so the notification is made useful rather than hidden.
 *
 * The views poll [state] rather than subscribing — fewer moving parts, and it
 * keeps the service unaware of any UI.
 */
class MeterService : Service() {

    companion object {
        private const val CHANNEL = "cue"
        private const val NOTE_ID = 1
        private const val SAMPLE_RATE = 44100
        private const val FRAME = 2048

        @Volatile var state: VoiceCue.State? = null
            private set

        @Volatile var running = false
            private set

        /** Paused keeps the service alive but stops looking at the microphone. */
        @Volatile var paused = false
            private set

        fun setPaused(value: Boolean) {
            paused = value
            if (value) state = null
        }

        fun micGranted(context: Context): Boolean =
            context.checkSelfPermission(Manifest.permission.RECORD_AUDIO) ==
                PackageManager.PERMISSION_GRANTED

        /** Called when the user changes the sensitivity or the calibration. */
        fun reloadSettings(context: Context) {
            pendingSettings = Prefs.marginDb(context) to Prefs.targetDbfs(context)
        }

        @Volatile internal var pendingSettings: Pair<Float, Float>? = null

        fun start(context: Context) {
            if (running || !micGranted(context)) return
            context.startForegroundService(Intent(context, MeterService::class.java))
        }
    }

    @Volatile private var cue = VoiceCue()
    private var worker: Thread? = null
    @Volatile private var stopping = false

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        val nm = getSystemService(NotificationManager::class.java)
        if (nm.getNotificationChannel(CHANNEL) == null) {
            nm.createNotificationChannel(
                NotificationChannel(
                    CHANNEL,
                    Prefs.text(this, R.string.notif_channel),
                    NotificationManager.IMPORTANCE_LOW
                )
                    .apply { setShowBadge(false) }
            )
        }
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (running) return START_STICKY

        val note = buildNotification()
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            startForeground(NOTE_ID, note, ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE)
        } else {
            startForeground(NOTE_ID, note)
        }

        cue = VoiceCue(
            marginDb = Prefs.marginDb(this),
            targetDbfs = Prefs.targetDbfs(this),
        )
        running = true
        stopping = false
        worker = thread(name = "meter") { listen() }
        return START_STICKY
    }

    override fun onDestroy() {
        stopping = true
        running = false
        paused = false
        state = null
        worker?.interrupt()
        worker = null
        super.onDestroy()
    }

    private fun buildNotification(): Notification {
        val open = PendingIntent.getActivity(
            this, 0,
            Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE
        )
        return Notification.Builder(this, CHANNEL)
            .setContentTitle(getString(R.string.app_name))
            .setContentText(Prefs.text(this, R.string.notif_text))
            .setSmallIcon(R.drawable.ic_note)
            .setContentIntent(open)
            .setOngoing(true)
            .build()
    }

    private var wasLit = false
    private var lastBuzzMs = 0L

    /**
     * The only cue available with the screen dark. Fires on the transition from
     * carrying to too-quiet while she is still talking — not on every quiet
     * frame, and never more than once every four seconds.
     */
    private fun buzzIfDropped(s: VoiceCue.State, nowMs: Long) {
        val dropped = wasLit && !s.lit && s.isSpeech
        wasLit = s.lit
        if (!dropped || nowMs - lastBuzzMs < 4000) return
        lastBuzzMs = nowMs

        val vibrator = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            (getSystemService(VibratorManager::class.java))?.defaultVibrator
        } else {
            @Suppress("DEPRECATION")
            getSystemService(Vibrator::class.java)
        } ?: return

        vibrator.vibrate(
            VibrationEffect.createWaveform(longArrayOf(0, 90, 120, 90), -1)
        )
    }

    private fun listen() {
        val minBuf = AudioRecord.getMinBufferSize(
            SAMPLE_RATE,
            AudioFormat.CHANNEL_IN_MONO,
            AudioFormat.ENCODING_PCM_FLOAT
        )
        val bufBytes = maxOf(minBuf, FRAME * 4 * 2)

        val recorder = try {
            AudioRecord.Builder()
                // UNPROCESSED where available: no automatic gain control fighting us.
                .setAudioSource(
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N)
                        MediaRecorder.AudioSource.UNPROCESSED
                    else
                        MediaRecorder.AudioSource.MIC
                )
                .setAudioFormat(
                    AudioFormat.Builder()
                        .setEncoding(AudioFormat.ENCODING_PCM_FLOAT)
                        .setSampleRate(SAMPLE_RATE)
                        .setChannelMask(AudioFormat.CHANNEL_IN_MONO)
                        .build()
                )
                .setBufferSizeInBytes(bufBytes)
                .build()
        } catch (e: Exception) {
            null
        } ?: return

        if (recorder.state != AudioRecord.STATE_INITIALIZED) {
            recorder.release()
            return
        }

        val buf = FloatArray(FRAME)
        try {
            recorder.startRecording()
            while (!stopping && running) {
                pendingSettings?.let { (margin, target) ->
                    pendingSettings = null
                    // Relearns the room, which is correct: a changed setting
                    // deserves a fresh look rather than a stale estimate.
                    cue = VoiceCue(marginDb = margin, targetDbfs = target)
                }
                val read = recorder.read(buf, 0, FRAME, AudioRecord.READ_BLOCKING)
                if (read <= 0) continue
                if (paused) continue
                val now = System.currentTimeMillis()
                val s = cue.push(if (read == FRAME) buf else buf.copyOf(read), now)
                state = s
                if (Prefs.screenMustStayDark(this)) buzzIfDropped(s, now)
            }
        } catch (e: Exception) {
            // Another app took the microphone. Leave state stale; the UI says so.
        } finally {
            try { recorder.stop() } catch (_: Exception) {}
            recorder.release()
        }
    }
}
