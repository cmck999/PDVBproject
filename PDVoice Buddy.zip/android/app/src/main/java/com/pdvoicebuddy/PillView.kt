package com.pdvoicebuddy

import android.content.Context
import android.content.Intent
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RadialGradient
import android.graphics.RectF
import android.graphics.Shader
import android.graphics.Typeface
import android.view.MotionEvent
import android.view.View

/**
 * The compact pill, for floating over other apps.
 *
 * Separate from [RingView] because a floating window is a fixed small size,
 * where the full-screen view scales everything off the shorter screen edge.
 * Sharing one class between the two would mean neither laid out properly.
 *
 * @param onDrag receives finger movement so the service can move the window.
 */
class PillView(
    context: Context,
    private val onDrag: (dx: Float, dy: Float) -> Unit,
    private val onDragEnd: () -> Unit
) : View(context) {

    private val core = Paint(Paint.ANTI_ALIAS_FLAG)
    private val halo = Paint(Paint.ANTI_ALIAS_FLAG)
    private val icon = Paint(Paint.ANTI_ALIAS_FLAG)
    private val label = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
    }

    private val shell = Color.parseColor("#12161C")
    private val dim = Color.parseColor("#39404A")
    private val paper = Color.parseColor("#C8CCD2")
    private val button = Color.parseColor("#1E242C")

    private var shownLevel = 0f
    private var shownLit = 0f
    private var haloShader: RadialGradient? = null
    private var haloRadius = 0f
    private var haloColour = 0

    private val shellRect = RectF()
    private val pauseRect = RectF()
    private val gearRect = RectF()
    private val closeRect = RectF()
    private val iconRect = RectF()
    private val iconPath = Path()

    private var downX = 0f
    private var downY = 0f
    private var lastX = 0f
    private var lastY = 0f
    private var dragging = false

    private val frame = object : Runnable {
        override fun run() {
            invalidate()
            postDelayed(this, 16L)
        }
    }

    override fun onAttachedToWindow() {
        super.onAttachedToWindow()
        post(frame)
    }

    override fun onDetachedFromWindow() {
        removeCallbacks(frame)
        super.onDetachedFromWindow()
    }

    override fun onTouchEvent(event: MotionEvent): Boolean {
        when (event.action) {
            MotionEvent.ACTION_DOWN -> {
                downX = event.rawX; downY = event.rawY
                lastX = event.rawX; lastY = event.rawY
                dragging = false
                return true
            }
            MotionEvent.ACTION_MOVE -> {
                val dx = event.rawX - lastX
                val dy = event.rawY - lastY
                if (!dragging &&
                    (kotlin.math.abs(event.rawX - downX) > 12f ||
                     kotlin.math.abs(event.rawY - downY) > 12f)
                ) dragging = true
                if (dragging) {
                    onDrag(dx, dy)
                    lastX = event.rawX; lastY = event.rawY
                }
                return true
            }
            MotionEvent.ACTION_UP -> {
                if (dragging) {
                    onDragEnd()
                } else when {
                    pauseRect.contains(event.x, event.y) ->
                        MeterService.setPaused(!MeterService.paused)
                    gearRect.contains(event.x, event.y) -> openSettings()
                    closeRect.contains(event.x, event.y) -> quit()
                    else -> openSettings()
                }
                return true
            }
        }
        return true
    }

    /** Shuts the whole thing down — pill, microphone and all. */
    private fun quit() {
        MeterService.setPaused(false)
        context.stopService(Intent(context, MeterService::class.java))
        OverlayService.stop(context)
    }

    private fun openSettings() {
        context.startActivity(
            Intent(context, SettingsActivity::class.java)
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        )
    }

    private fun chase(current: Float, target: Float, rise: Float, fall: Float): Float {
        val rate = if (target > current) rise else fall
        val next = current + (target - current) * rate
        return if (kotlin.math.abs(target - next) < 0.001f) target else next
    }

    override fun onDraw(canvas: Canvas) {
        val accent = Prefs.colour(context)
        val h = height.toFloat()
        val w = width.toFloat()
        val pad = h * 0.14f

        // Shell
        shellRect.set(pad, pad, w - pad, h - pad)
        core.shader = null
        core.color = shell
        canvas.drawRoundRect(shellRect, shellRect.height() / 2f, shellRect.height() / 2f, core)

        val cy = shellRect.centerY()
        val inner = shellRect.height()

        val state = MeterService.state
        val learning = state != null && !state.ready
        shownLevel = chase(
            shownLevel,
            if (learning || MeterService.paused) 0f else state?.level ?: 0f,
            rise = 0.35f, fall = 0.08f
        )
        shownLit = chase(
            shownLit,
            if (state?.lit == true && !MeterService.paused) 1f else 0f,
            rise = 0.30f, fall = 0.10f
        )

        // Dot
        val dotCx = shellRect.left + inner * 0.5f
        val radius = inner * (0.17f + 0.10f * shownLevel)
        val outer = radius * (1.9f + 1.5f * shownLevel)
        if (haloShader == null || haloColour != accent ||
            kotlin.math.abs(outer - haloRadius) > 1f
        ) {
            haloRadius = outer
            haloColour = accent
            haloShader = RadialGradient(
                dotCx, cy, outer,
                intArrayOf(accent, accent, Color.TRANSPARENT),
                floatArrayOf(0f, 0.18f, 1f),
                Shader.TileMode.CLAMP
            )
        }
        if (shownLit > 0.01f) {
            halo.shader = haloShader
            halo.alpha = (150f * shownLit * (0.45f + 0.55f * shownLevel)).toInt().coerceIn(0, 255)
            canvas.drawCircle(dotCx, cy, outer, halo)
        }
        core.shader = null
        core.color = blend(dim, accent, shownLit)
        canvas.drawCircle(dotCx, cy, radius, core)

        // Buttons, right-aligned. Close sits furthest out and unfilled, so it
        // is reachable but never the one you hit by accident.
        val bd = inner * 0.58f
        val gap = inner * 0.09f
        val closeCx = shellRect.right - inner * 0.30f - bd / 2f
        val gearCx = closeCx - bd - gap * 1.6f
        val pauseCx = gearCx - bd - gap
        pauseRect.set(pauseCx - bd / 2f, cy - bd / 2f, pauseCx + bd / 2f, cy + bd / 2f)
        gearRect.set(gearCx - bd / 2f, cy - bd / 2f, gearCx + bd / 2f, cy + bd / 2f)
        closeRect.set(closeCx - bd / 2f, cy - bd / 2f, closeCx + bd / 2f, cy + bd / 2f)

        core.color = button
        canvas.drawCircle(pauseCx, cy, bd / 2f, core)
        canvas.drawCircle(gearCx, cy, bd / 2f, core)
        drawTransport(canvas, pauseCx, cy, bd * 0.34f, !MeterService.paused)
        drawGear(canvas, gearCx, cy, bd * 0.42f)
        drawClose(canvas, closeCx, cy, bd * 0.32f)

        // Words, between dot and buttons
        val words = Prefs.text(
            context,
            when {
                MeterService.paused -> R.string.state_paused
                state == null -> R.string.state_starting
                learning -> R.string.state_learning_short
                shownLit > 0.5f -> R.string.state_heard
                else -> R.string.state_louder
            }
        )
        label.color = blend(paper, accent, shownLit)
        label.textSize = inner * 0.30f
        label.textAlign = Paint.Align.LEFT
        val textLeft = dotCx + inner * 0.42f
        val available = (pauseRect.left - inner * 0.14f) - textLeft
        if (available > label.measureText(words)) {
            canvas.drawText(words, textLeft, cy + label.textSize * 0.36f, label)
        }
    }

    private fun drawTransport(canvas: Canvas, cx: Float, cy: Float, size: Float, playing: Boolean) {
        icon.style = Paint.Style.FILL
        icon.color = paper
        if (playing) {
            val barW = size * 0.28f
            val gap = size * 0.24f
            iconRect.set(cx - gap / 2f - barW, cy - size / 2f, cx - gap / 2f, cy + size / 2f)
            canvas.drawRoundRect(iconRect, barW * 0.3f, barW * 0.3f, icon)
            iconRect.set(cx + gap / 2f, cy - size / 2f, cx + gap / 2f + barW, cy + size / 2f)
            canvas.drawRoundRect(iconRect, barW * 0.3f, barW * 0.3f, icon)
        } else {
            iconPath.reset()
            val w = size * 0.86f
            val left = cx - w * 0.38f
            iconPath.moveTo(left, cy - size / 2f)
            iconPath.lineTo(left + w, cy)
            iconPath.lineTo(left, cy + size / 2f)
            iconPath.close()
            canvas.drawPath(iconPath, icon)
        }
    }

    private fun drawClose(canvas: Canvas, cx: Float, cy: Float, size: Float) {
        icon.style = Paint.Style.STROKE
        icon.strokeWidth = size * 0.22f
        icon.strokeCap = Paint.Cap.ROUND
        icon.color = Color.parseColor("#7F858D")
        val r = size * 0.5f
        canvas.drawLine(cx - r, cy - r, cx + r, cy + r, icon)
        canvas.drawLine(cx + r, cy - r, cx - r, cy + r, icon)
        icon.style = Paint.Style.FILL
    }

    private fun drawGear(canvas: Canvas, cx: Float, cy: Float, size: Float) {
        val r = size * 0.5f
        icon.color = paper
        icon.style = Paint.Style.FILL
        val toothW = size * 0.19f
        val toothH = size * 0.26f
        for (i in 0 until 8) {
            canvas.save()
            canvas.rotate(i * 45f, cx, cy)
            iconRect.set(
                cx - toothW / 2f, cy - r - toothH * 0.42f,
                cx + toothW / 2f, cy - r + toothH * 0.58f
            )
            canvas.drawRoundRect(iconRect, toothW * 0.28f, toothW * 0.28f, icon)
            canvas.restore()
        }
        icon.style = Paint.Style.STROKE
        icon.strokeWidth = size * 0.22f
        canvas.drawCircle(cx, cy, r * 0.66f, icon)
        icon.style = Paint.Style.FILL
    }

    private fun blend(from: Int, to: Int, t: Float): Int {
        val k = t.coerceIn(0f, 1f)
        return Color.rgb(
            (Color.red(from) + (Color.red(to) - Color.red(from)) * k).toInt(),
            (Color.green(from) + (Color.green(to) - Color.green(from)) * k).toInt(),
            (Color.blue(from) + (Color.blue(to) - Color.blue(from)) * k).toInt()
        )
    }
}
