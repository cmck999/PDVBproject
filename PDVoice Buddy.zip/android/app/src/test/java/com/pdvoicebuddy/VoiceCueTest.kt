package com.pdvoicebuddy

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

/**
 * Phase 1: prove the model before building any app around it.
 *
 * These run on the PC with no tablet attached and no emulator.
 * In Android Studio: right-click this file -> Run 'VoiceCueTest'.
 */
class VoiceCueTest {

    /** Feed a steady level for a while, return the last verdict. */
    private fun settle(cue: VoiceCue, db: Float, ms: Long, startAt: Long = 0L): VoiceCue.State {
        var t = startAt
        var last = cue.pushDb(db, t)
        while (t < startAt + ms) {
            t += 46          // one 2048-frame window at 44.1 kHz
            last = cue.pushDb(db, t)
        }
        return last
    }

    @Test
    fun `silence never lights the dot`() {
        val cue = VoiceCue()
        val s = settle(cue, -55f, 5000)
        assertFalse("a quiet room must not read as speech", s.lit)
        assertFalse(s.isSpeech)
    }

    @Test
    fun `a raised voice lights it`() {
        val cue = VoiceCue()
        settle(cue, -55f, 5000)                     // learn the room
        val s = cue.pushDb(-35f, 5100)              // then speak up
        assertTrue("20 dB above the room should carry", s.lit)
        assertTrue(s.isSpeech)
    }

    @Test
    fun `it holds through the gaps between words`() {
        val cue = VoiceCue()
        settle(cue, -55f, 5000)
        cue.pushDb(-35f, 5000)                      // a word
        assertTrue("must not drop during a 300ms pause", cue.pushDb(-55f, 5300).lit)
        assertFalse("but must drop after a real silence", cue.pushDb(-55f, 6000).lit)
    }

    /**
     * The whole reason this model exists. The same voice level passes in a
     * quiet room and fails in a loud one — which is what being audible
     * actually means, and what a fixed dB threshold cannot express.
     */
    @Test
    fun `a louder room demands a louder voice`() {
        val voice = -35f

        val quietRoom = VoiceCue()
        settle(quietRoom, -55f, 5000)
        assertTrue("carries in a quiet kitchen", quietRoom.pushDb(voice, 5100).lit)

        val loudRoom = VoiceCue()
        settle(loudRoom, -38f, 5000)
        assertFalse("same voice is lost in a restaurant", loudRoom.pushDb(voice, 5100).lit)
    }

    /** If speech dragged the room estimate up, the cue would slowly go blind. */
    @Test
    fun `talking does not raise the room estimate much`() {
        val cue = VoiceCue()
        settle(cue, -55f, 5000)
        val quiet = cue.floorDb

        var t = 5000L
        repeat(200) {                               // ~9 seconds of talking
            t += 46
            cue.pushDb(-35f, t)
        }

        val drift = cue.floorDb - quiet
        assertTrue("floor drifted $drift dB during speech", drift < 4f)
        assertTrue("and the dot is still lit", cue.pushDb(-35f, t + 46).lit)
    }

    /** A dishwasher starting should raise the bar, not light the dot. */
    @Test
    fun `steady noise raises the bar rather than triggering`() {
        val cue = VoiceCue()
        settle(cue, -55f, 4000)
        val s = settle(cue, -40f, 90_000, startAt = 4000)   // noise for 90s
        assertFalse("a running appliance must not read as her voice", s.lit)
    }

    /**
     * The bug this catches, found on a real tablet: the room estimate starts
     * at whatever it first hears. If the app opens during a quiet moment and
     * the room is steadily noisier than that, a too-slow rise rate leaves the
     * dot falsely lit for minutes. It should settle in seconds.
     */
    @Test
    fun `a noisy room settles quickly after starting`() {
        val cue = VoiceCue()
        cue.pushDb(-70f, 0)                                 // opened in a lull
        val afterFive = settle(cue, -45f, 5000, startAt = 0) // then steady room noise
        assertFalse("must not still be lit five seconds in", afterFive.lit)
        assertFalse(afterFive.isSpeech)

        // And it must still notice a real voice above that room.
        assertTrue("a raised voice still carries", cue.pushDb(-30f, 5200).lit)
    }

    /** Nothing should be reported as a verdict before the room is known. */
    @Test
    fun `it reports not-ready while learning the room`() {
        val cue = VoiceCue()
        assertFalse("first frame cannot know the room", cue.pushDb(-50f, 0).ready)
        assertFalse("nor can it light the dot", cue.pushDb(-20f, 200).lit)
        assertTrue("but it is ready soon after", settle(cue, -50f, 2500).ready)
    }

    @Test
    fun `the relative half alone ignores absolute scale`() {
        // Same 20 dB gap, wildly different absolute levels. With no absolute
        // target the verdict must match — this is the relative half in
        // isolation, and it is still the half that handles noisy rooms.
        val near = VoiceCue()
        settle(near, -50f, 5000)
        val nearState = near.pushDb(-30f, 5100)

        val far = VoiceCue()
        settle(far, -70f, 5000)
        val farState = far.pushDb(-50f, 5100)

        assertEquals("with no target, scale must not change it", nearState.lit, farState.lit)
        assertTrue(nearState.lit)
    }

    /**
     * The correction that prompted the absolute target, from a Parkinson's
     * physician's assistant: in a silent room, clearing the room proves
     * nothing. A whisper is 20 dB above a very quiet library, and rewarding it
     * teaches the opposite of what the app is for.
     */
    @Test
    fun `a whisper in a silent room does not light the dot`() {
        val target = -32f                        // about 63 dB SPL
        val cue = VoiceCue(marginDb = 13f, targetDbfs = target)
        settle(cue, -75f, 5000)                  // an almost silent room

        val whisper = cue.pushDb(-50f, 5100)     // 25 dB above the room…
        assertTrue("comfortably clears the room", whisper.aboveDb > 13f)
        assertFalse("but is nowhere near conversational", whisper.lit)
        assertTrue("and the absolute bar is the binding one", whisper.absoluteBinding)

        val spoken = cue.pushDb(-30f, 5200)
        assertTrue("a real speaking voice does light it", spoken.lit)
    }

    /** In a loud room the room is still the binding constraint, as before. */
    @Test
    fun `in a noisy room the room sets the bar`() {
        val cue = VoiceCue(marginDb = 13f, targetDbfs = -32f)
        settle(cue, -30f, 5000)                  // a busy restaurant

        val s = cue.pushDb(-25f, 5100)           // above the absolute target…
        assertFalse("clearing the target is not enough here", s.lit)
        assertFalse("the room is binding, not the target", s.absoluteBinding)
        assertTrue("and it takes more to be heard", cue.pushDb(-15f, 5200).lit)
    }

    /** The bar is simply the higher of the two, at any room level. */
    @Test
    fun `the bar is whichever threshold is higher`() {
        val target = -32f
        val quiet = VoiceCue(marginDb = 13f, targetDbfs = target)
        val quietState = settle(quiet, -70f, 5000)
        assertEquals("quiet room: the target holds", target, quietState.thresholdDb, 0.5f)

        val loud = VoiceCue(marginDb = 13f, targetDbfs = target)
        val loudState = settle(loud, -30f, 5000)
        assertTrue("loud room: the room holds", loudState.thresholdDb > target)
    }

    @Test
    fun `level rises smoothly rather than snapping`() {
        val cue = VoiceCue()
        settle(cue, -55f, 5000)
        val soft = cue.pushDb(-48f, 5100).level
        val mid = cue.pushDb(-40f, 5180).level
        val loud = cue.pushDb(-30f, 5260).level
        assertTrue("the dot should grow as she gets louder", soft < mid && mid < loud)
        assertEquals("and cap at 1", 1f, cue.pushDb(-10f, 5340).level, 0.001f)
    }

    @Test
    fun `dbOf is sane`() {
        assertTrue(VoiceCue.dbOf(FloatArray(512)) < -100f)
        val loud = VoiceCue.dbOf(FloatArray(512) { 0.5f })
        val soft = VoiceCue.dbOf(FloatArray(512) { 0.05f })
        assertTrue(loud > soft)
        assertEquals("half scale is about -6 dBFS", -6f, loud, 0.5f)
    }
}
