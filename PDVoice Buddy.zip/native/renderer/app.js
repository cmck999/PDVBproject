// PDVoice Buddy — renderer. Owns the microphone, the loudness engine, and the flag UI.
// Nothing is recorded: each 80 ms window produces one number and is thrown away.

const COLLAPSED = 214;
const EXPANDED = 464;
const BARS = 40;
const TICK_MS = 80;
const HOLD_MS = 700;
const LIT = '#74d49c';

const el = {
  ring: document.getElementById('ring'),
  status: document.getElementById('status'),
  sub: document.getElementById('sub'),
  mute: document.getElementById('mute'),
  trace: document.getElementById('trace'),
  settingsRow: document.getElementById('settingsRow'),
  settingsLabel: document.getElementById('settingsLabel'),
  settingsChevron: document.getElementById('settingsChevron'),
  panel: document.getElementById('panel'),
  threshold: document.getElementById('threshold'),
  thrVal: document.getElementById('thrVal'),
  calibrate: document.getElementById('calibrate'),
  calibNote: document.getElementById('calibNote'),
  session: document.getElementById('session'),
  quit: document.getElementById('quit')
};

const store = {
  get(k, fallback) {
    const v = localStorage.getItem('buddy.' + k);
    return v === null ? fallback : JSON.parse(v);
  },
  set(k, v) { localStorage.setItem('buddy.' + k, JSON.stringify(v)); }
};

const state = {
  mic: 'starting',
  muted: false,
  lit: false,
  db: 40,
  threshold: store.get('threshold', 60),
  noiseFloor: store.get('noiseFloor', null),
  calibOffset: store.get('calibOffset', 94),
  calibrating: false,
  calibLeft: 0,
  panelOpen: false,
  history: new Array(BARS).fill(null)
};

// Daily tally, reset when the date changes.
const today = new Date().toISOString().slice(0, 10);
let log = store.get('log', {});
if (!log[today]) log[today] = { speech: 0, projected: 0 };

let audio = null;
let timer = null;
let lastAbove = -1e9;
let calibSamples = null;
let calibEnd = 0;

// ---- audio ----------------------------------------------------------------

async function startMic() {
  if (audio) return;
  state.mic = 'starting';
  render();
  try {
    const stream = await navigator.mediaDevices.getUserMedia({
      audio: { echoCancellation: false, noiseSuppression: false, autoGainControl: false }
    });
    const ctx = new AudioContext();
    const an = ctx.createAnalyser();
    an.fftSize = 2048;
    ctx.createMediaStreamSource(stream).connect(an);
    audio = { stream, ctx, an, buf: new Float32Array(an.fftSize) };
    state.mic = 'on';
    timer = setInterval(tick, TICK_MS);
  } catch (err) {
    state.mic = 'denied';
  }
  render();
}

function stopMic() {
  if (timer) { clearInterval(timer); timer = null; }
  if (audio) {
    audio.stream.getTracks().forEach(t => t.stop());
    audio.ctx.close();
    audio = null;
  }
  if (state.mic === 'on' || state.mic === 'starting') state.mic = 'off';
  state.lit = false;
  state.history = new Array(BARS).fill(null);
}

function tick() {
  if (!audio) return;
  audio.an.getFloatTimeDomainData(audio.buf);
  let sum = 0;
  for (let i = 0; i < audio.buf.length; i++) sum += audio.buf[i] * audio.buf[i];
  const rms = Math.sqrt(sum / audio.buf.length);
  const db = Math.max(30, Math.min(95, 20 * Math.log10(Math.max(rms, 1e-7)) + state.calibOffset));
  state.db = db;

  if (state.calibrating) {
    calibSamples.push(db);
    state.calibLeft = Math.max(0, Math.ceil((calibEnd - performance.now()) / 1000));
    if (performance.now() >= calibEnd) finishCalibration();
    render();
    return;
  }

  const now = performance.now();
  if (db >= state.threshold) lastAbove = now;
  state.lit = now - lastAbove < HOLD_MS;

  state.history = state.history.concat([db]).slice(-BARS);

  const floor = state.noiseFloor;
  const isSpeech = floor == null ? db > 45 : db > floor + 8;
  if (isSpeech) {
    log[today].speech += 1;
    if (db >= state.threshold) log[today].projected += 1;
    if (log[today].speech % 25 === 0) store.set('log', log);
  }

  render();
}

// ---- calibration ----------------------------------------------------------

function startCalibration() {
  if (state.mic !== 'on') { state.muted = false; startMic(); return; }
  calibSamples = [];
  calibEnd = performance.now() + 5000;
  state.calibrating = true;
  state.calibLeft = 5;
  render();
}

function finishCalibration() {
  const sorted = calibSamples.slice().sort((a, b) => a - b);
  const median = sorted.length ? Math.round(sorted[Math.floor(sorted.length / 2)]) : 40;
  state.calibrating = false;
  state.calibLeft = 0;
  state.noiseFloor = median;
  state.threshold = Math.min(85, Math.max(50, median + 18));
  store.set('noiseFloor', state.noiseFloor);
  store.set('threshold', state.threshold);
}

// ---- render ---------------------------------------------------------------

function statusCopy() {
  if (state.muted) return ['Paused', 'Tap the button to start again'];
  if (state.calibrating) return ['Listening to the room', 'Stay quiet for ' + state.calibLeft + ' more seconds'];
  if (state.mic === 'denied') return ['Microphone blocked', 'Allow the microphone in system settings'];
  if (state.mic === 'starting') return ['Waking up…', 'Turning the microphone on'];
  if (state.lit) return ['They can hear you', percentCopy()];
  return ['A little louder', percentCopy()];
}

function percentCopy() {
  const d = log[today];
  if (!d.speech) return 'Say something and watch the ring';
  return Math.round(d.projected / d.speech * 100) + '% of today at a good volume';
}

function render() {
  const [status, sub] = statusCopy();
  el.status.textContent = status;
  el.sub.textContent = sub;

  const dim = state.muted ? '#5b6068' : '#8c8f96';
  el.ring.style.borderColor = state.lit ? LIT : dim;
  el.ring.style.boxShadow = state.lit ? '0 0 26px ' + LIT + '99' : 'none';
  el.status.style.color = state.lit ? LIT : state.muted ? '#9aa0a8' : '#e2e4e8';

  el.mute.textContent = state.muted ? 'On' : 'Off';
  el.mute.title = state.muted ? 'Start listening' : 'Pause listening';
  el.mute.classList.toggle('on', state.muted);

  if (el.trace.childElementCount !== BARS) {
    el.trace.innerHTML = '';
    for (let i = 0; i < BARS; i++) el.trace.appendChild(document.createElement('div'));
  }
  state.history.forEach((v, i) => {
    const bar = el.trace.children[i];
    bar.style.height = (v == null ? 8 : Math.max(6, Math.min(100, (v - 35) / 55 * 100))) + '%';
    bar.style.background = v == null ? 'rgba(255,255,255,0.14)'
      : v >= state.threshold ? LIT : 'rgba(255,255,255,0.26)';
  });

  el.thrVal.textContent = state.threshold + ' dB';
  el.threshold.value = state.threshold;

  el.calibrate.disabled = state.calibrating;
  el.calibrate.textContent = state.calibrating ? state.calibLeft + '…'
    : state.mic !== 'on' ? 'Turn the microphone on first'
    : state.noiseFloor != null ? 'Measure the room again' : 'Measure the room';
  el.calibNote.textContent = state.noiseFloor != null
    ? 'Room floor ' + state.noiseFloor + ' dB. Target set 18 dB above it. Measure again if you move rooms.'
    : 'Five seconds of quiet from your usual chair sets a target that fits this room.';

  const d = log[today];
  el.session.textContent = d.speech
    ? 'Today: ' + Math.round(d.projected / d.speech * 100) + '% projected'
    : 'Today: nothing measured yet';

  el.settingsLabel.textContent = state.panelOpen ? 'Hide settings' : 'Settings';
  el.settingsChevron.textContent = state.panelOpen ? '–' : '+';
}

// ---- interaction ----------------------------------------------------------

function toggleListening() {
  if (state.mic === 'denied') { state.mic = 'off'; state.muted = false; startMic(); return; }
  if (state.muted) { state.muted = false; startMic(); }
  else { stopMic(); state.muted = true; }
  window.buddy.listeningChanged(state.muted);
  render();
}

el.mute.addEventListener('click', toggleListening);
window.buddy.onToggleListening(toggleListening);

el.settingsRow.addEventListener('click', () => {
  state.panelOpen = !state.panelOpen;
  el.panel.classList.toggle('open', state.panelOpen);
  window.buddy.setHeight(state.panelOpen ? EXPANDED : COLLAPSED);
  render();
});

el.threshold.addEventListener('input', (e) => {
  state.threshold = parseInt(e.target.value, 10);
  store.set('threshold', state.threshold);
  render();
});

el.calibrate.addEventListener('click', startCalibration);
el.quit.addEventListener('click', () => { store.set('log', log); window.buddy.quit(); });
window.addEventListener('beforeunload', () => store.set('log', log));

render();
startMic();
