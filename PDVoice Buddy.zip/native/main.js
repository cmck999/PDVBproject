const { app, BrowserWindow, Tray, Menu, ipcMain, screen, shell, nativeImage } = require('electron');
const path = require('path');

const COLLAPSED_HEIGHT = 214;
const WIDTH = 340;
const MARGIN = 24;

let win = null;
let tray = null;
let quitting = false;

// Only one copy of the app should ever run.
if (!app.requestSingleInstanceLock()) {
  app.quit();
} else {
  app.on('second-instance', () => {
    if (win) { win.show(); win.focus(); }
  });
}

function cornerPosition(height) {
  const display = screen.getPrimaryDisplay();
  const { x, y, width: dw, height: dh } = display.workArea;
  return {
    x: Math.round(x + dw - WIDTH - MARGIN),
    y: Math.round(y + dh - height - MARGIN)
  };
}

function createWindow() {
  const pos = cornerPosition(COLLAPSED_HEIGHT);

  win = new BrowserWindow({
    width: WIDTH,
    height: COLLAPSED_HEIGHT,
    x: pos.x,
    y: pos.y,
    frame: false,
    transparent: true,
    backgroundColor: '#00000000',
    hasShadow: true,
    resizable: false,
    movable: true,
    minimizable: false,
    maximizable: false,
    fullscreenable: false,
    skipTaskbar: true,
    alwaysOnTop: true,
    show: false,
    webPreferences: {
      preload: path.join(__dirname, 'preload.js'),
      contextIsolation: true,
      nodeIntegration: false
    }
  });

  // Float above full-screen apps and video calls, which is the whole point.
  win.setAlwaysOnTop(true, 'screen-saver');
  win.setVisibleOnAllWorkspaces(true, { visibleOnFullScreen: true });

  // Grant the microphone once, for good — the patient never sees a prompt.
  win.webContents.session.setPermissionRequestHandler((wc, permission, callback) => {
    callback(permission === 'media' || permission === 'audioCapture');
  });
  win.webContents.session.setPermissionCheckHandler(() => true);

  win.loadFile(path.join(__dirname, 'renderer', 'index.html'));
  win.once('ready-to-show', () => win.show());

  // Closing the flag hides it rather than killing the app; Quit lives in the tray.
  win.on('close', (e) => {
    if (!quitting) { e.preventDefault(); win.hide(); }
  });

  win.webContents.setWindowOpenHandler(({ url }) => {
    shell.openExternal(url);
    return { action: 'deny' };
  });
}

function trayIcon() {
  const img = nativeImage.createFromPath(path.join(__dirname, 'assets', 'tray.png'));
  const resized = img.isEmpty() ? img : img.resize({ width: 18, height: 18 });
  resized.setTemplateImage(process.platform === 'darwin');
  return resized;
}

function buildTray() {
  tray = new Tray(trayIcon());
  tray.setToolTip('PDVoice Buddy');
  refreshTrayMenu(false);
  tray.on('click', () => (win.isVisible() ? win.hide() : win.show()));
}

function refreshTrayMenu(paused) {
  const openAtLogin = app.getLoginItemSettings().openAtLogin;
  tray.setContextMenu(Menu.buildFromTemplate([
    {
      label: win && win.isVisible() ? 'Hide the flag' : 'Show the flag',
      click: () => (win.isVisible() ? win.hide() : win.show())
    },
    {
      label: paused ? 'Start listening' : 'Pause listening',
      click: () => win.webContents.send('toggle-listening')
    },
    { type: 'separator' },
    {
      label: 'Move to bottom right',
      click: () => {
        const [, h] = win.getSize();
        const p = cornerPosition(h);
        win.setPosition(p.x, p.y, false);
      }
    },
    {
      label: 'Open at login',
      type: 'checkbox',
      checked: openAtLogin,
      click: (item) => {
        app.setLoginItemSettings({ openAtLogin: item.checked, openAsHidden: false });
        refreshTrayMenu(paused);
      }
    },
    { type: 'separator' },
    { label: 'Quit PDVoice Buddy', click: () => { quitting = true; app.quit(); } }
  ]));
}

// The flag grows when settings open; keep it pinned to its corner as it does.
ipcMain.on('set-height', (_e, height) => {
  if (!win) return;
  const h = Math.max(120, Math.round(height));
  const [x, y] = win.getPosition();
  const [, oldH] = win.getSize();
  win.setBounds({ x, y: y - (h - oldH), width: WIDTH, height: h }, false);
});

ipcMain.on('listening-changed', (_e, paused) => refreshTrayMenu(!!paused));
ipcMain.on('quit-app', () => { quitting = true; app.quit(); });

app.whenReady().then(() => {
  if (process.platform === 'darwin' && app.dock) app.dock.hide();
  // First launch: start with the machine from then on.
  if (!app.getLoginItemSettings().openAtLogin) {
    app.setLoginItemSettings({ openAtLogin: true, openAsHidden: false });
  }
  createWindow();
  buildTray();
});

app.on('window-all-closed', (e) => e.preventDefault());
app.on('before-quit', () => { quitting = true; });
