const { contextBridge, ipcRenderer } = require('electron');

contextBridge.exposeInMainWorld('buddy', {
  setHeight: (h) => ipcRenderer.send('set-height', h),
  listeningChanged: (paused) => ipcRenderer.send('listening-changed', paused),
  quit: () => ipcRenderer.send('quit-app'),
  onToggleListening: (fn) => ipcRenderer.on('toggle-listening', () => fn())
});
